/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ActiveTab, AppState, BusinessLocation, DailyRecord, InventoryItem, WeeklyOwnerDraw } from './types';
import {
  loadAppState,
  saveAppState,
  getInitialLocations,
  getInitialInventory,
  getInitialDailyRecords,
  getInitialWeeklyOwnerDraws,
  exportMonthlyReportToExcel,
} from './utils/storage';
import { Header } from './components/Header';
import { DailyEntryTab } from './components/tabs/DailyEntryTab';
import { WeeklySummaryTab } from './components/tabs/WeeklySummaryTab';
import { MonthlySummaryTab } from './components/tabs/MonthlySummaryTab';
import { InventoryTab } from './components/tabs/InventoryTab';
import { AnalyticsTab } from './components/tabs/AnalyticsTab';
import { PrintReportModal } from './components/modals/PrintReportModal';
import { ChangePasswordModal } from './components/modals/ChangePasswordModal';
import { LoginScreen } from './components/auth/LoginScreen';
import { calculateDailyRent, calculateMonthlySummary, calculateLocationDailyRent, safeNum } from './utils/calculations';
import { downloadMonthlyReportPDF } from './utils/pdfGenerator';

export default function App() {
  const [appState, setAppState] = useState<AppState>(() => loadAppState());
  const [activeTab, setActiveTab] = useState<ActiveTab>('daily');
  
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return (
      localStorage.getItem('avoaddict_auth') === 'true' ||
      sessionStorage.getItem('avoaddict_auth') === 'true'
    );
  });

  const [currentUser, setCurrentUser] = useState<string>(() => {
    return (
      localStorage.getItem('avoaddict_user') ||
      sessionStorage.getItem('avoaddict_user') ||
      'Admin'
    );
  });

  const handleLogin = (user: string) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('avoaddict_auth');
    localStorage.removeItem('avoaddict_user');
    sessionStorage.removeItem('avoaddict_auth');
    sessionStorage.removeItem('avoaddict_user');
    setIsAuthenticated(false);
  };
  
  const todayStr = new Date().toISOString().split('T')[0];
  const [selectedMonth, setSelectedMonth] = useState<string>(todayStr.substring(0, 7));
  const [selectedDateForDaily, setSelectedDateForDaily] = useState<string>(todayStr);

  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);

  // Persist state updates
  const updateState = (newState: AppState) => {
    setAppState(newState);
    saveAppState(newState);
  };

  // Locations Handlers (integrated in Daily tab with days and date range)
  const handleAddLocation = (newLoc: Omit<BusinessLocation, 'id' | 'dailyRent'>) => {
    const id = `loc-${Date.now()}`;
    const operatingDays = newLoc.operatingDays && newLoc.operatingDays > 0 ? newLoc.operatingDays : 6;
    const dailyRent = Number((safeNum(newLoc.weeklyRent) / operatingDays).toFixed(2));
    const updated = [...appState.locations, { ...newLoc, id, dailyRent, operatingDays }];
    updateState({ ...appState, locations: updated });
  };

  const handleUpdateLocation = (loc: BusinessLocation) => {
    const operatingDays = loc.operatingDays && loc.operatingDays > 0 ? loc.operatingDays : 6;
    const dailyRent = Number((safeNum(loc.weeklyRent) / operatingDays).toFixed(2));
    const updated = appState.locations.map((l) => (l.id === loc.id ? { ...loc, dailyRent, operatingDays } : l));
    updateState({ ...appState, locations: updated });
  };

  const handleDeleteLocation = (id: string) => {
    const updated = appState.locations.filter((l) => l.id !== id);
    updateState({ ...appState, locations: updated });
  };

  // Daily Records Handlers
  const handleSaveDailyRecord = (record: DailyRecord) => {
    const existingIndex = appState.dailyRecords.findIndex((r) => r.date === record.date);
    let updated: DailyRecord[];
    if (existingIndex >= 0) {
      updated = [...appState.dailyRecords];
      updated[existingIndex] = record;
    } else {
      updated = [record, ...appState.dailyRecords];
    }
    updateState({ ...appState, dailyRecords: updated });
  };

  const handleDeleteDailyRecord = (id: string) => {
    const updated = appState.dailyRecords.filter((r) => r.id !== id);
    updateState({ ...appState, dailyRecords: updated });
  };

  // Weekly Owner Draw Handler
  const handleSaveOwnerDraw = (draw: WeeklyOwnerDraw) => {
    const existingIndex = appState.weeklyOwnerDraws.findIndex((d) => d.startDate === draw.startDate);
    let updated: WeeklyOwnerDraw[];
    if (existingIndex >= 0) {
      updated = [...appState.weeklyOwnerDraws];
      updated[existingIndex] = draw;
    } else {
      updated = [...appState.weeklyOwnerDraws, draw];
    }
    updateState({ ...appState, weeklyOwnerDraws: updated });
  };

  // Inventory Handlers
  const handleAddInventoryItem = (item: Omit<InventoryItem, 'id' | 'totalCost'>) => {
    const id = `inv-${Date.now()}`;
    const totalCost = Number((item.quantity * item.unitCost).toFixed(2));
    const newItem: InventoryItem = { ...item, id, totalCost };
    const updated = [newItem, ...appState.inventoryItems];
    updateState({ ...appState, inventoryItems: updated });
  };

  const handleUpdateInventoryItem = (item: InventoryItem) => {
    const updated = appState.inventoryItems.map((i) => (i.id === item.id ? item : i));
    updateState({ ...appState, inventoryItems: updated });
  };

  const handleDeleteInventoryItem = (id: string) => {
    const updated = appState.inventoryItems.filter((i) => i.id !== id);
    updateState({ ...appState, inventoryItems: updated });
  };

  // Download Current Monthly Report in Excel
  const handleDownloadExcelReport = () => {
    const summary = calculateMonthlySummary(
      selectedMonth,
      appState.dailyRecords,
      appState.locations,
      appState.weeklyOwnerDraws,
      appState.inventoryItems
    );
    exportMonthlyReportToExcel(selectedMonth, summary, summary.records, appState.locations);
  };

  const handleDownloadPDFReport = () => {
    const summary = calculateMonthlySummary(
      selectedMonth,
      appState.dailyRecords,
      appState.locations,
      appState.weeklyOwnerDraws,
      appState.inventoryItems
    );
    downloadMonthlyReportPDF(
      selectedMonth,
      summary,
      summary.records,
      appState.locations,
      appState.inventoryItems,
      appState.weeklyOwnerDraws
    );
  };

  // Quick navigation helper
  const handleNavigateToDaily = (dateStr: string) => {
    setSelectedDateForDaily(dateStr);
    setActiveTab('daily');
    window.scrollTo({ top: 380, behavior: 'smooth' });
  };

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans w-full max-w-full overflow-x-hidden">
      {/* EXACTLY ONE SINGLE NAVIGATION BAR */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenChangePassword={() => setIsChangePasswordOpen(true)}
        onOpenQuickEntry={() => {
          setSelectedDateForDaily(new Date().toISOString().split('T')[0]);
          setActiveTab('daily');
          window.scrollTo({ top: 380, behavior: 'smooth' });
        }}
        onDownloadExcel={handleDownloadExcelReport}
        onDownloadPDF={handleDownloadPDFReport}
        onOpenPrintModal={() => setIsPrintModalOpen(true)}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-5 sm:py-7 overflow-x-hidden">
        {activeTab === 'daily' && (
          <DailyEntryTab
            locations={appState.locations}
            dailyRecords={appState.dailyRecords}
            onSaveDailyRecord={handleSaveDailyRecord}
            onDeleteDailyRecord={handleDeleteDailyRecord}
            onAddLocation={handleAddLocation}
            onUpdateLocation={handleUpdateLocation}
            onDeleteLocation={handleDeleteLocation}
            selectedDate={selectedDateForDaily}
            onOpenPrintModal={() => setIsPrintModalOpen(true)}
          />
        )}

        {activeTab === 'weekly' && (
          <WeeklySummaryTab
            locations={appState.locations}
            dailyRecords={appState.dailyRecords}
            weeklyOwnerDraws={appState.weeklyOwnerDraws}
            onSaveOwnerDraw={handleSaveOwnerDraw}
            onNavigateToDaily={handleNavigateToDaily}
            onOpenPrintModal={() => setIsPrintModalOpen(true)}
          />
        )}

        {activeTab === 'monthly' && (
          <MonthlySummaryTab
            locations={appState.locations}
            dailyRecords={appState.dailyRecords}
            weeklyOwnerDraws={appState.weeklyOwnerDraws}
            inventoryItems={appState.inventoryItems}
            selectedMonth={selectedMonth}
            setSelectedMonth={setSelectedMonth}
            onOpenPrintModal={() => setIsPrintModalOpen(true)}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryTab
            inventoryItems={appState.inventoryItems}
            onAddInventoryItem={handleAddInventoryItem}
            onUpdateInventoryItem={handleUpdateInventoryItem}
            onDeleteInventoryItem={handleDeleteInventoryItem}
            selectedMonth={selectedMonth}
            setSelectedMonth={setSelectedMonth}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsTab
            locations={appState.locations}
            dailyRecords={appState.dailyRecords}
            weeklyOwnerDraws={appState.weeklyOwnerDraws}
            inventoryItems={appState.inventoryItems}
            selectedMonth={selectedMonth}
            onOpenPrintModal={() => setIsPrintModalOpen(true)}
            onNavigateToDaily={handleNavigateToDaily}
          />
        )}
      </main>

      {/* Printable / Download PDF Report Modal */}
      <PrintReportModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        selectedMonth={selectedMonth}
        locations={appState.locations}
        dailyRecords={appState.dailyRecords}
        weeklyOwnerDraws={appState.weeklyOwnerDraws}
        inventoryItems={appState.inventoryItems}
      />

      {/* Change Password Modal */}
      <ChangePasswordModal
        isOpen={isChangePasswordOpen}
        onClose={() => setIsChangePasswordOpen(false)}
      />
    </div>
  );
}
