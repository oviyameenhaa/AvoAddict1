import React, { useState } from 'react';
import { ActiveTab } from '../types';
import {
  Calendar,
  PlusCircle,
  FileSpreadsheet,
  Printer,
  Download,
  Menu,
  X,
  FileText,
  CalendarDays,
  PieChart,
  Package,
  TrendingUp,
  LogOut,
  UserCheck,
  KeyRound,
} from 'lucide-react';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenQuickEntry: () => void;
  onDownloadExcel: () => void;
  onDownloadPDF: () => void;
  onOpenPrintModal: () => void;
  currentUser?: string;
  onLogout?: () => void;
  onOpenChangePassword?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenQuickEntry,
  onDownloadExcel,
  onDownloadPDF,
  onOpenPrintModal,
  currentUser,
  onLogout,
  onOpenChangePassword,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const currentDate = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  const navItems: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'daily', label: 'Daily Entry & Rent', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'weekly', label: 'Weekly Summary', icon: <CalendarDays className="w-3.5 h-3.5" /> },
    { id: 'monthly', label: 'Monthly P&L', icon: <PieChart className="w-3.5 h-3.5" /> },
    { id: 'inventory', label: 'Inventory Tracker', icon: <Package className="w-3.5 h-3.5" /> },
    { id: 'analytics', label: 'Analytics', icon: <TrendingUp className="w-3.5 h-3.5" /> },
  ];

  const handleTabClick = (tab: ActiveTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-40 shadow-xs">
      {/* Primary Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-2">
          {/* Brand Zone: Official Mascot Logo directly next to AvoAddict */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => handleTabClick('daily')}
              className="text-left group cursor-pointer focus:outline-none flex items-center gap-2 sm:gap-2.5"
            >
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden shadow-xs border border-emerald-500/30 bg-black flex items-center justify-center shrink-0 ring-2 ring-emerald-500/10">
                <img
                  src="/logo.jpg"
                  alt="AvoAddict Official Logo"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-base sm:text-lg font-black tracking-tight text-slate-900 group-hover:text-emerald-700 transition-colors leading-tight">
                  AvoAddict
                </span>
                <span className="text-[9px] sm:text-[10px] font-bold text-emerald-700 uppercase tracking-wider leading-none hidden xs:block">
                  Operations Hub
                </span>
              </div>
            </button>
          </div>

          {/* Desktop Navigation Links (>= md) */}
          <nav className="hidden md:flex items-center gap-3 lg:gap-5 text-xs lg:text-sm font-semibold shrink-0">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`transition-colors whitespace-nowrap pb-0.5 cursor-pointer ${
                  activeTab === item.id
                    ? 'text-slate-900 font-bold border-b-2 border-emerald-600'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Action Buttons Zone - Fully responsive to prevent overflow on any screen */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <div className="hidden xl:flex items-center text-xs font-medium text-slate-400 mr-1">
              <Calendar className="w-3.5 h-3.5 mr-1 text-slate-400" />
              <span>{currentDate}</span>
            </div>

            {/* Download Excel Button - hidden on xs phones to prevent header overflow */}
            <button
              onClick={onDownloadExcel}
              title="Download Report in Excel (.xlsx)"
              className="hidden sm:flex px-2.5 sm:px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg sm:rounded-xl transition-colors items-center gap-1.5 whitespace-nowrap cursor-pointer shadow-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span className="hidden md:inline">Download</span>
              <span>Excel</span>
            </button>

            {/* Download PDF Button - hidden on xs phones to prevent header overflow */}
            <button
              onClick={onDownloadPDF}
              title="Download Report in PDF (.pdf)"
              className="hidden sm:flex px-2.5 sm:px-3 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg sm:rounded-xl shadow-xs transition-colors items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-slate-200 shrink-0" />
              <span className="hidden md:inline">Download</span>
              <span>PDF</span>
            </button>

            {/* Quick Log Daily Entry Button */}
            <button
              onClick={onOpenQuickEntry}
              className="px-2 sm:px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg sm:rounded-xl shadow-xs transition-colors flex items-center gap-1 sm:gap-1.5 whitespace-nowrap cursor-pointer shrink-0"
              title="Quick Log Today's Entry"
            >
              <PlusCircle className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden xs:inline">+ Log Daily</span>
              <span className="xs:hidden">+ Entry</span>
            </button>

            {/* User Badge */}
            {currentUser && (
              <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-900 text-xs font-semibold border border-emerald-200 shrink-0">
                <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>{currentUser}</span>
              </div>
            )}

            {/* Change Password Button */}
            {onOpenChangePassword && (
              <button
                type="button"
                onClick={onOpenChangePassword}
                title="Change security password"
                className="flex items-center gap-1 p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-bold text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-200 rounded-lg sm:rounded-xl transition-colors cursor-pointer shrink-0"
              >
                <KeyRound className="w-3.5 h-3.5 text-slate-500" />
                <span className="hidden md:inline">Password</span>
              </button>
            )}

            {/* Sign Out Button */}
            {onLogout && (
              <button
                type="button"
                onClick={onLogout}
                title="Sign out of Operations Hub"
                className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-slate-600 hover:text-red-700 hover:bg-red-50 border border-slate-200 hover:border-red-200 rounded-xl transition-colors cursor-pointer shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Sign Out</span>
              </button>
            )}

            {/* Mobile Menu Toggle Button (< md) */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 md:hidden cursor-pointer shrink-0"
              title="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Touch Navigation Ribbon (< md screen width) */}
      <div className="md:hidden border-t border-slate-100 bg-slate-50/90 overflow-x-auto no-scrollbar py-1.5 px-3">
        <div className="flex items-center gap-1 whitespace-nowrap">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 bg-white border border-slate-200'
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Mobile Full Dropdown Menu (< md) when hamburger toggled */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 py-3 space-y-2 shadow-lg animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
            Navigation Sections
          </div>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 text-sm font-semibold rounded-xl text-left transition-colors cursor-pointer ${
                activeTab === item.id
                  ? 'bg-emerald-50 text-emerald-800 font-bold border border-emerald-200'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className={activeTab === item.id ? 'text-emerald-600' : 'text-slate-400'}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </div>
              {activeTab === item.id && (
                <span className="text-xs text-emerald-700 font-mono font-bold">Active</span>
              )}
            </button>
          ))}

          <div className="pt-2 border-t border-slate-100 space-y-1.5">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Download Reports
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  onDownloadExcel();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                <span>Excel (.xlsx)</span>
              </button>
              <button
                onClick={() => {
                  onDownloadPDF();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PDF Report</span>
              </button>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-1.5 font-medium text-slate-700">
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{currentUser || 'Admin'}</span>
            </div>
            <div className="flex items-center gap-3">
              {onOpenChangePassword && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenChangePassword();
                  }}
                  className="text-xs font-bold text-slate-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
                >
                  <KeyRound className="w-3.5 h-3.5 text-slate-400" />
                  <span>Password</span>
                </button>
              )}
              {onLogout && (
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onLogout();
                  }}
                  className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
