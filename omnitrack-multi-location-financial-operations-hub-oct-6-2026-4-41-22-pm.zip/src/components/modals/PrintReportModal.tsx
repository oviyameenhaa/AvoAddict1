import React from 'react';
import { BusinessLocation, DailyRecord, InventoryItem, WeeklyOwnerDraw } from '../../types';
import {
  calculateMonthlySummary,
  formatCurrency,
  formatPercent,
  formatNumber,
} from '../../utils/calculations';
import { X, Printer, Download, FileSpreadsheet } from 'lucide-react';
import { exportMonthlyReportToExcel } from '../../utils/storage';
import { downloadMonthlyReportPDF } from '../../utils/pdfGenerator';

interface PrintReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedMonth: string;
  locations: BusinessLocation[];
  dailyRecords: DailyRecord[];
  weeklyOwnerDraws: WeeklyOwnerDraw[];
  inventoryItems: InventoryItem[];
}

export const PrintReportModal: React.FC<PrintReportModalProps> = ({
  isOpen,
  onClose,
  selectedMonth,
  locations,
  dailyRecords,
  weeklyOwnerDraws,
  inventoryItems,
}) => {
  if (!isOpen) return null;

  const summary = calculateMonthlySummary(
    selectedMonth,
    dailyRecords,
    locations,
    weeklyOwnerDraws,
    inventoryItems
  );

  const [yearStr, monthStr] = selectedMonth.split('-');
  const monthName = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1).toLocaleDateString(
    'en-US',
    { month: 'long', year: 'numeric' }
  );

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white text-slate-900 rounded-2xl shadow-2xl w-full max-w-4xl my-8 overflow-hidden border border-slate-200">
        {/* Modal Controls Bar (Responsive, no cutoff) */}
        <div className="no-print p-4 bg-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-bold">
            <div className="w-6 h-6 rounded-md overflow-hidden bg-black border border-emerald-500/40 shrink-0 flex items-center justify-center">
              <img src="/logo.jpg" alt="Logo" className="w-full h-full object-contain" />
            </div>
            <span className="break-words">AvoAddict Monthly Financial Report ({monthName})</span>
          </div>
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={() => downloadMonthlyReportPDF(selectedMonth, summary, summary.records, locations, inventoryItems, weeklyOwnerDraws)}
              className="px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
              title="Download actual PDF document to your device"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>
            <button
              onClick={() => exportMonthlyReportToExcel(selectedMonth, summary, summary.records, locations)}
              className="px-3 py-1.5 text-xs font-semibold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Download Excel spreadsheet"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span>Download Excel</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Print document via system print dialog"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer ml-1"
              title="Close Report"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Page Container */}
        <div className="p-8 sm:p-12 space-y-8 bg-white print:p-0">
          {/* Header & Branding */}
          <div className="border-b-2 border-slate-900 pb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl overflow-hidden bg-black border border-emerald-500/40 shrink-0 flex items-center justify-center">
                  <img src="/logo.jpg" alt="AvoAddict Logo" className="w-full h-full object-contain" />
                </div>
                <h1 className="text-2xl font-black tracking-tight text-slate-900">
                  AvoAddict Sdn. Bhd.
                </h1>
              </div>
              <p className="text-sm font-semibold text-slate-600 mt-0.5">
                Specialty Avocado & Beverage Group — Management Accounts (RM)
              </p>
              <div className="text-xs text-slate-500 mt-1">
                Active Booth Locations: {locations.filter((l) => l.isActive).map((l) => `${l.name} (RM ${formatNumber(l.weeklyRent)}/wk)`).join(', ')}
              </div>
            </div>

            <div className="text-left sm:text-right">
              <div className="text-lg font-black font-mono text-slate-900">{monthName}</div>
              <div className="text-xs text-slate-500 font-mono">
                Report Date: {new Date().toLocaleDateString('en-MY')}
              </div>
              <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider mt-1">
                Official Monthly P&L Ledger
              </div>
            </div>
          </div>

          {/* Executive KPI Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-300">
            <div>
              <div className="text-[11px] font-bold text-slate-500 uppercase">Gross Revenue</div>
              <div className="text-xl font-black font-mono text-slate-900">
                {formatCurrency(summary.totalRevenue)}
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Bank: {formatCurrency(summary.totalBankRevenue)} | Cash: {formatCurrency(summary.totalCashRevenue)}
              </div>
            </div>

            <div>
              <div className="text-[11px] font-bold text-slate-500 uppercase">Operating Costs</div>
              <div className="text-xl font-black font-mono text-slate-900">
                {formatCurrency(summary.totalExpenses)}
              </div>
              <div className="text-[10px] text-slate-500">Rent + Staff + Supplies + Draw</div>
            </div>

            <div>
              <div className="text-[11px] font-bold text-slate-500 uppercase">Net Monthly Profit</div>
              <div
                className={`text-xl font-black font-mono ${
                  summary.monthlyNetProfit >= 0 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {formatCurrency(summary.monthlyNetProfit)}
              </div>
              <div className="text-[10px] text-slate-600 font-mono font-bold">
                Margin: {formatPercent(summary.profitMargin)}
              </div>
            </div>

            <div>
              <div className="text-[11px] font-bold text-slate-500 uppercase">Operating Coverage</div>
              <div className="text-xl font-black font-mono text-slate-900">
                {summary.daysLogged} Days
              </div>
              <div className="text-[10px] text-slate-500">Logged Shifts</div>
            </div>
          </div>

          {/* Statement of Financial Performance */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-900 border-b border-slate-300 pb-1">
              Statement of Financial Performance (All figures in RM)
            </h2>

            <table className="w-full text-xs">
              <tbody className="divide-y divide-slate-200">
                <tr className="font-semibold bg-slate-50">
                  <td className="py-2 px-3">1. Operating Sales Revenue</td>
                  <td className="py-2 px-3 text-right font-mono font-bold">
                    {formatCurrency(summary.totalRevenue)}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 px-6 text-slate-600">Merchant Bank & DuitNow QR Inflow</td>
                  <td className="py-1.5 px-3 text-right font-mono text-slate-700">
                    {formatCurrency(summary.totalBankRevenue)}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 px-6 text-slate-600">Physical Register Cash Inflow</td>
                  <td className="py-1.5 px-3 text-right font-mono text-slate-700">
                    {formatCurrency(summary.totalCashRevenue)}
                  </td>
                </tr>

                <tr className="font-semibold bg-slate-50">
                  <td className="py-2 px-3">2. Operating Expenses & Direct Costs</td>
                  <td className="py-2 px-3 text-right font-mono font-bold">
                    {formatCurrency(summary.totalExpenses)}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 px-6 text-slate-600">
                    Branch Rental Overhead (Daily Rent × Logged Operating Days)
                  </td>
                  <td className="py-1.5 px-3 text-right font-mono text-slate-700">
                    {formatCurrency(summary.totalRental)}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 px-6 text-slate-600">Crew Staff Salaries & Shift Payroll</td>
                  <td className="py-1.5 px-3 text-right font-mono text-slate-700">
                    {formatCurrency(summary.totalStaffSalaries)}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 px-6 text-slate-600">
                    Inventory & Goods (Avocado Hass, Wakame, Botol PET, NSK Mix, Susu Milk)
                  </td>
                  <td className="py-1.5 px-3 text-right font-mono text-slate-700">
                    {formatCurrency(summary.totalInventoryCost)}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 px-6 text-slate-600">Founder&apos;s Draw / &quot;My Salary&quot; Distributions</td>
                  <td className="py-1.5 px-3 text-right font-mono text-slate-700">
                    {formatCurrency(summary.totalOwnersDraw)}
                  </td>
                </tr>

                <tr className="border-t-2 border-slate-900 font-bold text-sm bg-slate-100">
                  <td className="py-2.5 px-3">Net Operational Income / Bottom Line (RM)</td>
                  <td
                    className={`py-2.5 px-3 text-right font-mono font-black ${
                      summary.monthlyNetProfit >= 0 ? 'text-emerald-700' : 'text-red-700'
                    }`}
                  >
                    {formatCurrency(summary.monthlyNetProfit)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Signatures */}
          <div className="pt-8 border-t border-slate-300 grid grid-cols-2 gap-8 text-xs text-slate-600">
            <div>
              <div className="h-10 border-b border-slate-400"></div>
              <p className="mt-1 font-bold text-slate-800">Store General Manager</p>
              <p className="text-[11px] text-slate-500">Certified accurate from daily register tally</p>
            </div>
            <div>
              <div className="h-10 border-b border-slate-400"></div>
              <p className="mt-1 font-bold text-slate-800">Founder / Managing Director</p>
              <p className="text-[11px] text-slate-500">AvoAddict Sdn. Bhd. Internal Review</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
