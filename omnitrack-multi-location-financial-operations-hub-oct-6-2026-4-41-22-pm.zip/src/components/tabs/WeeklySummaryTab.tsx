import React, { useState, useMemo } from 'react';
import { BusinessLocation, DailyRecord, WeeklyOwnerDraw } from '../../types';
import {
  calculateWeeklySummary,
  calculateTotalWeeklyRent,
  formatCurrency,
  formatPercent,
  getWeekBounds,
  getWeeksInMonth,
  safeNum,
} from '../../utils/calculations';
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  User,
  TrendingUp,
  FileCheck2,
  FileSpreadsheet,
  Printer,
  Download,
} from 'lucide-react';
import { exportWeeklyReportToExcel } from '../../utils/storage';
import { downloadWeeklyReportPDF } from '../../utils/pdfGenerator';

interface WeeklySummaryTabProps {
  locations: BusinessLocation[];
  dailyRecords: DailyRecord[];
  weeklyOwnerDraws: WeeklyOwnerDraw[];
  onSaveOwnerDraw: (draw: WeeklyOwnerDraw) => void;
  onNavigateToDaily: (date: string) => void;
  onOpenPrintModal?: () => void;
}

export const WeeklySummaryTab: React.FC<WeeklySummaryTabProps> = ({
  locations,
  dailyRecords,
  weeklyOwnerDraws,
  onSaveOwnerDraw,
  onNavigateToDaily,
  onOpenPrintModal,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const initialWeekBounds = getWeekBounds(todayStr);

  const [selectedStartDate, setSelectedStartDate] = useState<string>(initialWeekBounds.startDate);
  const [selectedEndDate, setSelectedEndDate] = useState<string>(initialWeekBounds.endDate);
  const [currentMonth, setCurrentMonth] = useState<string>(todayStr.substring(0, 7));

  const availableWeeks = useMemo(() => getWeeksInMonth(currentMonth), [currentMonth]);

  const summary = useMemo(() => {
    return calculateWeeklySummary(
      selectedStartDate,
      selectedEndDate,
      dailyRecords,
      locations,
      weeklyOwnerDraws
    );
  }, [selectedStartDate, selectedEndDate, dailyRecords, locations, weeklyOwnerDraws]);

  const existingDraw = weeklyOwnerDraws.find((d) => d.startDate === selectedStartDate);
  const [drawAmountStr, setDrawAmountStr] = useState<string>(
    existingDraw ? existingDraw.amount.toString() : ''
  );
  const [isSavedNotice, setIsSavedNotice] = useState(false);

  React.useEffect(() => {
    const draw = weeklyOwnerDraws.find((d) => d.startDate === selectedStartDate);
    setDrawAmountStr(draw ? draw.amount.toString() : '');
  }, [selectedStartDate, weeklyOwnerDraws]);

  const handleSaveDraw = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = safeNum(drawAmountStr);
    onSaveOwnerDraw({
      weekKey: `draw-${selectedStartDate}`,
      startDate: selectedStartDate,
      endDate: selectedEndDate,
      amount,
      notes: `AvoAddict Owner's Draw for week of ${selectedStartDate}`,
    });
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 2500);
  };

  const handleShiftWeek = (direction: 'prev' | 'next') => {
    const curr = new Date(selectedStartDate + 'T00:00:00');
    const dayShift = direction === 'prev' ? -7 : 7;
    curr.setDate(curr.getDate() + dayShift);
    const bounds = getWeekBounds(curr.toISOString().split('T')[0]);
    setSelectedStartDate(bounds.startDate);
    setSelectedEndDate(bounds.endDate);
  };

  const weekDays = useMemo(() => {
    const days: Array<{
      dateStr: string;
      dayName: string;
      record?: DailyRecord;
    }> = [];
    const start = new Date(selectedStartDate + 'T00:00:00');

    for (let i = 0; i < 7; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const iso = d.toISOString().split('T')[0];
      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
      const record = dailyRecords.find((r) => r.date === iso);
      days.push({ dateStr: iso, dayName, record });
    }
    return days;
  }, [selectedStartDate, dailyRecords]);

  return (
    <div className="space-y-6">
      {/* Week Selector Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>AvoAddict Weekly Operations & P&L Summary</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Weekly sales aggregation, booth operating rent, crew payroll, and founder distributions in RM.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            type="month"
            aria-label="Select Month for Weekly Presets"
            value={currentMonth}
            onChange={(e) => {
              setCurrentMonth(e.target.value);
              const weeks = getWeeksInMonth(e.target.value);
              if (weeks.length > 0) {
                setSelectedStartDate(weeks[0].startDate);
                setSelectedEndDate(weeks[0].endDate);
              }
            }}
            className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none"
          />

          <select
            value={selectedStartDate}
            onChange={(e) => {
              const selectedWeek = availableWeeks.find((w) => w.startDate === e.target.value);
              if (selectedWeek) {
                setSelectedStartDate(selectedWeek.startDate);
                setSelectedEndDate(selectedWeek.endDate);
              }
            }}
            aria-label="Select Week Interval"
            className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none"
          >
            {availableWeeks.map((w) => (
              <option key={w.startDate} value={w.startDate}>
                {w.label}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-1">
            <button
              onClick={() => handleShiftWeek('prev')}
              className="p-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-600 cursor-pointer"
              title="Previous Week"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => handleShiftWeek('next')}
              className="p-1.5 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-600 cursor-pointer"
              title="Next Week"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const currentWeek = availableWeeks.find((w) => w.startDate === selectedStartDate);
                exportWeeklyReportToExcel(selectedStartDate, selectedEndDate, summary, summary.records);
              }}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Download Weekly Report in Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              <span>Download Excel</span>
            </button>
            <button
              onClick={() => {
                downloadWeeklyReportPDF(selectedStartDate, selectedEndDate, summary, summary.records, locations);
              }}
              className="px-3 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
              title="Download Weekly Report PDF to your device"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* 5-Card Metric Summary Grid (Bright style) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Total Weekly Revenue */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            1. Weekly Revenue (RM)
          </div>
          <div className="text-2xl font-black font-mono text-slate-900">
            {formatCurrency(summary.totalWeeklyRevenue)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {summary.daysLogged} operating days logged
          </div>
        </div>

        {/* Total Weekly Rental */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            2. Weekly Rent (RM)
          </div>
          <div className="text-2xl font-black font-mono text-slate-900">
            {formatCurrency(summary.totalWeeklyRent)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Based on days operated
          </div>
        </div>

        {/* Total Weekly Staff Payroll */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            3. Staff Salaries (RM)
          </div>
          <div className="text-2xl font-black font-mono text-slate-900">
            {formatCurrency(summary.totalStaffSalary)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Crew shift payroll
          </div>
        </div>

        {/* Owner's Draw ("My Salary") Input Card */}
        <div className="p-5 rounded-2xl bg-blue-50/50 border border-blue-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-blue-800 uppercase tracking-wider mb-1">
            <span>4. &quot;My Salary&quot; / Draw (RM)</span>
            <User className="w-3.5 h-3.5" />
          </div>
          <form onSubmit={handleSaveDraw} className="space-y-1.5">
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-400 font-mono text-xs font-bold">
                RM
              </span>
              <input
                type="number"
                step="0.01"
                min="0"
                placeholder="1500.00"
                value={drawAmountStr}
                onChange={(e) => setDrawAmountStr(e.target.value)}
                className="w-full pl-9 pr-2 py-1 text-base font-mono font-bold rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-slate-500">Weekly Founder Draw</span>
              <button
                type="submit"
                className="text-[11px] font-bold text-blue-700 hover:text-blue-900 cursor-pointer"
              >
                {isSavedNotice ? 'Saved!' : 'Update'}
              </button>
            </div>
          </form>
        </div>

        {/* Net Profit of the Week */}
        <div
          className={`p-5 rounded-2xl border shadow-sm ${
            summary.netProfit >= 0
              ? 'bg-emerald-50/60 border-emerald-200'
              : 'bg-red-50/60 border-red-200'
          }`}
        >
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">
            Net Profit (Week)
          </div>
          <div
            className={`text-2xl font-black font-mono ${
              summary.netProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
            }`}
          >
            {formatCurrency(summary.netProfit)}
          </div>
          <div className="text-[11px] text-slate-600 mt-1 font-mono font-semibold">
            Margin: {formatPercent(summary.profitMargin)}
          </div>
        </div>
      </div>

      {/* Day-by-Day Performance Matrix */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              7-Day Performance Matrix ({selectedStartDate} to {selectedEndDate})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Daily revenue vs daily booth rent and staff payroll in RM.
            </p>
          </div>
          <span className="text-xs font-mono font-semibold text-slate-600">
            {summary.daysLogged} Operating Days Logged
          </span>
        </div>

        {/* Mobile Days Cards (< sm) to fit 100% screen width without side-by-side scrolling */}
        <div className="sm:hidden p-4 space-y-3">
          {weekDays.map(({ dateStr, dayName, record }) => {
            const isLogged = !!record;
            const isPositive = isLogged && record.netDailyBalance >= 0;
            return (
              <div
                key={dateStr}
                className={`p-3.5 rounded-2xl border transition-all ${
                  isLogged ? 'bg-white border-slate-200 shadow-xs' : 'bg-slate-50 border-slate-200 opacity-80'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-900">{dayName}</span>
                    <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                      {dateStr}
                    </span>
                  </div>
                  {isLogged ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                      <FileCheck2 className="w-3.5 h-3.5" />
                      <span>Logged</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-medium text-slate-400 bg-slate-200/60 px-2 py-0.5 rounded-full">
                      Off / Unlogged
                    </span>
                  )}
                </div>

                {isLogged ? (
                  <>
                    <div className="grid grid-cols-2 gap-2 py-2 border-y border-slate-100 font-mono text-xs">
                      <div>
                        <div className="text-[10px] font-sans text-slate-500 uppercase font-medium">Revenue (In)</div>
                        <div className="font-bold text-slate-900 mt-0.5">{formatCurrency(record.totalCashIn)}</div>
                        <div className="text-[10px] text-slate-400 font-sans">
                          Bank {formatCurrency(record.bankRevenue)} · Cash {formatCurrency(record.cashRevenue)}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] font-sans text-slate-500 uppercase font-medium">Daily Balance</div>
                        <div className={`font-bold mt-0.5 ${isPositive ? 'text-emerald-700' : 'text-red-600'}`}>
                          {formatCurrency(record.netDailyBalance)}
                        </div>
                        <div className="text-[10px] text-slate-400 font-sans">
                          Rent {formatCurrency(record.dailyRentSnapshot)} · Payroll {formatCurrency(record.totalStaffSalary)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-end mt-2.5 pt-2 border-t border-slate-100">
                      <button
                        onClick={() => onNavigateToDaily(dateStr)}
                        className="px-3 py-1 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
                      >
                        Edit Shift
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs text-slate-400">No shift recorded yet</span>
                    <button
                      onClick={() => onNavigateToDaily(dateStr)}
                      className="px-3 py-1 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      + Log Day
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Desktop / Tablet Table (>= sm) */}
        <div className="hidden sm:block overflow-x-auto table-responsive-container">
          <table className="w-full min-w-[760px] text-left text-xs">
            <thead className="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-600 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Day & Date</th>
                <th className="py-3 px-4 font-semibold text-center">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Bank (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Cash (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Total Revenue (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Daily Rent (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Staff Payroll (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Daily Balance (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {weekDays.map(({ dateStr, dayName, record }) => {
                const isLogged = !!record;
                return (
                  <tr key={dateStr} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3.5 px-4 font-sans">
                      <div className="font-semibold text-slate-900 flex items-center gap-2">
                        <span className="w-9 text-slate-500 text-xs">{dayName}</span>
                        <span>{dateStr}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center font-sans">
                      {isLogged ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
                          <FileCheck2 className="w-3.5 h-3.5" />
                          <span>Logged</span>
                        </span>
                      ) : (
                        <span className="text-[11px] text-slate-400">Off / Unlogged</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right text-slate-600">
                      {isLogged ? formatCurrency(record.bankRevenue) : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right text-slate-600">
                      {isLogged ? formatCurrency(record.cashRevenue) : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                      {isLogged ? formatCurrency(record.totalCashIn) : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right text-slate-500">
                      {isLogged ? formatCurrency(record.dailyRentSnapshot) : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right text-slate-600">
                      {isLogged ? formatCurrency(record.totalStaffSalary) : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      {isLogged ? (
                        <span
                          className={`font-bold ${
                            record.netDailyBalance >= 0 ? 'text-emerald-700' : 'text-red-600'
                          }`}
                        >
                          {formatCurrency(record.netDailyBalance)}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right font-sans">
                      <button
                        onClick={() => onNavigateToDaily(dateStr)}
                        className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
                      >
                        {isLogged ? 'Edit' : '+ Log Day'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-50 font-semibold border-t border-slate-200">
              <tr>
                <td colSpan={4} className="py-3 px-4 font-sans text-slate-900">
                  Total 7-Day Performance
                </td>
                <td className="py-3 px-4 text-right font-mono text-slate-900 text-sm">
                  {formatCurrency(summary.totalWeeklyRevenue)}
                </td>
                <td className="py-3 px-4 text-right font-mono text-slate-600">
                  {formatCurrency(summary.totalWeeklyRent)}
                </td>
                <td className="py-3 px-4 text-right font-mono text-slate-600">
                  {formatCurrency(summary.totalStaffSalary)}
                </td>
                <td className="py-3 px-4 text-right font-mono text-emerald-700 text-sm">
                  {formatCurrency(
                    summary.totalWeeklyRevenue - (summary.totalWeeklyRent + summary.totalStaffSalary)
                  )}
                </td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
};
