import React, { useState, useEffect } from 'react';
import { BusinessLocation, DailyRecord, StaffSalaryLine } from '../../types';
import {
  calculateDailyRent,
  calculateTotalDailyRent,
  calculateTotalWeeklyRent,
  calculateLocationDailyRent,
  isLocationActiveOnDate,
  formatCurrency,
  formatPercent,
  formatNumber,
  safeNum,
} from '../../utils/calculations';
import {
  Calendar,
  Building2,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  AlertTriangle,
  CheckCircle2,
  Search,
  FileSpreadsheet,
  Copy,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Store,
  Sparkles,
  ArrowRight,
  Printer,
  Download,
  CalendarRange,
} from 'lucide-react';
import { exportDailyLedgerToExcel } from '../../utils/storage';
import { downloadDailyShiftPDF, downloadMonthlyReportPDF, downloadDailyLedgerPDF } from '../../utils/pdfGenerator';

interface DailyEntryTabProps {
  locations: BusinessLocation[];
  dailyRecords: DailyRecord[];
  onSaveDailyRecord: (record: DailyRecord) => void;
  onDeleteDailyRecord: (id: string) => void;
  onAddLocation: (loc: Omit<BusinessLocation, 'id' | 'dailyRent'>) => void;
  onUpdateLocation: (loc: BusinessLocation) => void;
  onDeleteLocation: (id: string) => void;
  selectedDate?: string;
  onOpenPrintModal?: () => void;
}

export const DailyEntryTab: React.FC<DailyEntryTabProps> = ({
  locations,
  dailyRecords,
  onSaveDailyRecord,
  onDeleteDailyRecord,
  onAddLocation,
  onUpdateLocation,
  onDeleteLocation,
  selectedDate: initialSelectedDate,
  onOpenPrintModal,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const [date, setDate] = useState<string>(initialSelectedDate || todayStr);
  const [bankRevenue, setBankRevenue] = useState<string>('');
  const [cashRevenue, setCashRevenue] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [staffList, setStaffList] = useState<StaffSalaryLine[]>([
    { id: '1', name: '', amount: 140, bottlesSold: 0 },
    { id: '2', name: '', amount: 110, bottlesSold: 0 },
  ]);
  const [isSavedToastVisible, setIsSavedToastVisible] = useState(false);
  const [lastSavedRecord, setLastSavedRecord] = useState<DailyRecord | null>(null);

  // Section visibility toggles
  const [isLocationsExpanded, setIsLocationsExpanded] = useState<boolean>(true);
  const [showAddLocationForm, setShowAddLocationForm] = useState<boolean>(false);
  const [editingLocId, setEditingLocId] = useState<string | null>(null);

  // Functional deletion confirmation states (NO window.confirm which fails in sandboxes!)
  const [confirmDeleteLocId, setConfirmDeleteLocId] = useState<string | null>(null);
  const [confirmDeleteRecId, setConfirmDeleteRecId] = useState<string | null>(null);

  // New Location Form State with Days & Date Picker Option
  const [newLocName, setNewLocName] = useState('');
  const [newLocCode, setNewLocCode] = useState('');
  const [newLocWeeklyRent, setNewLocWeeklyRent] = useState('');
  const [newLocManager, setNewLocManager] = useState('');
  const [newLocDays, setNewLocDays] = useState<string>('6'); // Operating days per week (1-7)
  const [newLocStartDate, setNewLocStartDate] = useState<string>(''); // Date picker start
  const [newLocEndDate, setNewLocEndDate] = useState<string>(''); // Date picker end

  // Edit Location State
  const [editLocName, setEditLocName] = useState('');
  const [editLocWeeklyRent, setEditLocWeeklyRent] = useState('');
  const [editLocCode, setEditLocCode] = useState('');
  const [editLocManager, setEditLocManager] = useState('');
  const [editLocDays, setEditLocDays] = useState<string>('6');
  const [editLocStartDate, setEditLocStartDate] = useState<string>('');
  const [editLocEndDate, setEditLocEndDate] = useState<string>('');

  // Search & Filter state for historical ledger
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilterStart, setDateFilterStart] = useState('');
  const [dateFilterEnd, setDateFilterEnd] = useState('');

  // BOOTH BUSINESS CALCULATION WITH DAYS DIVISION & OPERATING DATES:
  // Each booth's weekly rent is divided by the number of days it operates (default 6).
  // Total Daily Rent for the shift = Sum of active booths operating on this date.
  const activeLocationsOnDate = locations.filter((l) => isLocationActiveOnDate(l, date));
  const totalWeeklyRent = activeLocationsOnDate.reduce((sum, l) => sum + safeNum(l.weeklyRent), 0);
  const activeBoothCount = activeLocationsOnDate.length;
  const totalDailyRent = calculateTotalDailyRent(locations, undefined, date);

  // If entry exists for selected date, load it
  useEffect(() => {
    const existing = dailyRecords.find((r) => r.date === date);
    if (existing) {
      setBankRevenue(existing.bankRevenue > 0 ? existing.bankRevenue.toString() : '');
      setCashRevenue(existing.cashRevenue > 0 ? existing.cashRevenue.toString() : '');
      setNotes(existing.notes || '');
      setStaffList(
        existing.staffSalaries && existing.staffSalaries.length > 0
          ? existing.staffSalaries
          : [
              { id: '1', name: '', amount: 140, bottlesSold: 0 },
              { id: '2', name: '', amount: 110, bottlesSold: 0 },
            ]
      );
    } else {
      setBankRevenue('');
      setCashRevenue('');
      setNotes('');
      setStaffList([
        { id: `stf-1-${Date.now()}`, name: '', amount: 140, bottlesSold: 0 },
        { id: `stf-2-${Date.now()}`, name: '', amount: 110, bottlesSold: 0 },
      ]);
    }
  }, [date, dailyRecords]);

  // Live Auto-Calculations
  const numBank = safeNum(bankRevenue);
  const numCash = safeNum(cashRevenue);
  const totalCashIn = numBank + numCash;

  const totalStaffSalary = staffList.reduce((sum, item) => sum + safeNum(item.amount), 0);
  const totalBottlesSoldToday = staffList.reduce((sum, item) => sum + (safeNum(item.bottlesSold) || 0), 0);
  const totalCashOut = totalDailyRent + totalStaffSalary;
  const netDailyBalance = totalCashIn - totalCashOut;

  // Low margin warning check: (rent + staff) > 60% of revenue
  const expenseRatio = totalCashIn > 0 ? totalCashOut / totalCashIn : 0;
  const isLowMarginWarning = totalCashIn > 0 && expenseRatio > 0.60;

  // Add Staff Row
  const handleAddStaff = () => {
    const newStaff: StaffSalaryLine = {
      id: `staff-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: '',
      amount: 95,
      bottlesSold: 0,
    };
    setStaffList([...staffList, newStaff]);
  };

  // Remove Staff Row (Guaranteed Functional Delete)
  const handleRemoveStaff = (id: string) => {
    setStaffList((prev) => prev.filter((s) => s.id !== id));
  };

  // Update Staff Row
  const handleUpdateStaff = (id: string, field: keyof StaffSalaryLine, value: any) => {
    setStaffList(
      staffList.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            [field]: field === 'amount'
              ? safeNum(value)
              : field === 'bottlesSold'
              ? Math.max(0, parseInt(value, 10) || 0)
              : value,
          };
        }
        return item;
      })
    );
  };

  // Copy staff roster from most recent logged entry
  const handleCopyRecentStaffRoster = () => {
    const recentWithStaff = [...dailyRecords]
      .sort((a, b) => b.date.localeCompare(a.date))
      .find((r) => r.staffSalaries && r.staffSalaries.length > 0 && r.date !== date);

    if (recentWithStaff && recentWithStaff.staffSalaries.length > 0) {
      setStaffList(
        recentWithStaff.staffSalaries.map((s, idx) => ({
          ...s,
          id: `copied-${Date.now()}-${idx}`,
        }))
      );
    }
  };

  // Location Creation
  const handleCreateLocation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLocName.trim()) return;

    const weeklyRent = safeNum(newLocWeeklyRent);
    const operatingDays = Math.max(1, Math.min(7, parseInt(newLocDays, 10) || 6));

    onAddLocation({
      name: newLocName.trim(),
      code: newLocCode.trim().toUpperCase() || `AA-0${locations.length + 1}`,
      weeklyRent,
      operatingDays,
      startDate: newLocStartDate.trim() || undefined,
      endDate: newLocEndDate.trim() || undefined,
      managerName: newLocManager.trim(),
      isActive: true,
    });

    setNewLocName('');
    setNewLocCode('');
    setNewLocWeeklyRent('');
    setNewLocDays('6');
    setNewLocStartDate('');
    setNewLocEndDate('');
    setNewLocManager('');
    setShowAddLocationForm(false);
  };

  const handleStartEditLoc = (loc: BusinessLocation) => {
    setEditingLocId(loc.id);
    setEditLocName(loc.name);
    setEditLocWeeklyRent(loc.weeklyRent.toString());
    setEditLocCode(loc.code);
    setEditLocManager(loc.managerName || '');
    setEditLocDays((loc.operatingDays || 6).toString());
    setEditLocStartDate(loc.startDate || '');
    setEditLocEndDate(loc.endDate || '');
  };

  const handleSaveEditLoc = (id: string, original: BusinessLocation) => {
    const weeklyRent = safeNum(editLocWeeklyRent);
    const operatingDays = Math.max(1, Math.min(7, parseInt(editLocDays, 10) || 6));

    onUpdateLocation({
      ...original,
      name: editLocName.trim() || original.name,
      weeklyRent,
      operatingDays,
      startDate: editLocStartDate.trim() || undefined,
      endDate: editLocEndDate.trim() || undefined,
      code: editLocCode.trim().toUpperCase() || original.code,
      managerName: editLocManager.trim(),
    });
    setEditingLocId(null);
  };

  // Fully functional Delete Location
  const executeDeleteLocation = (id: string) => {
    onDeleteLocation(id);
    setConfirmDeleteLocId(null);
  };

  // Fully functional Delete Daily Record
  const executeDeleteRecord = (id: string) => {
    onDeleteDailyRecord(id);
    setConfirmDeleteRecId(null);
  };

  // Save Daily Record
  const handleSaveEntry = (e?: React.FormEvent) => {
    if (e && e.preventDefault) {
      e.preventDefault();
    }

    const recordId = `rec-${date}`;
    const newRecord: DailyRecord = {
      id: recordId,
      date,
      locationId: 'ALL',
      bankRevenue: numBank,
      cashRevenue: numCash,
      totalCashIn,
      staffSalaries: staffList.filter((s) => s.name.trim() !== '' || s.amount > 0 || ((s.bottlesSold ?? 0) > 0)),
      totalStaffSalary,
      dailyRentSnapshot: totalDailyRent,
      totalCashOut,
      netDailyBalance,
      notes: notes.trim(),
    };

    onSaveDailyRecord(newRecord);
    setLastSavedRecord(newRecord);
    setIsSavedToastVisible(true);
    setTimeout(() => setIsSavedToastVisible(false), 4500);
  };

  // Filter historical records
  const filteredHistory = dailyRecords.filter((record) => {
    if (dateFilterStart && record.date < dateFilterStart) return false;
    if (dateFilterEnd && record.date > dateFilterEnd) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const dateMatch = record.date.includes(q);
      const notesMatch = (record.notes || '').toLowerCase().includes(q);
      const staffMatch = record.staffSalaries?.some((s) => s.name.toLowerCase().includes(q));
      return dateMatch || notesMatch || staffMatch;
    }

    return true;
  });

  const handleShiftDay = (days: number) => {
    const curr = new Date(date + 'T00:00:00');
    curr.setDate(curr.getDate() + days);
    setDate(curr.toISOString().split('T')[0]);
  };

  const selectedDateObj = new Date(date + 'T00:00:00');
  const dayOfWeekName = selectedDateObj.toLocaleDateString('en-US', { weekday: 'long' });
  const formattedFullDate = selectedDateObj.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const isDateToday = date === todayStr;
  const isDateSavedInLedger = dailyRecords.some((r) => r.date === date);

  return (
    <div className="space-y-8">
      {/* ============================================================ */}
      {/* 0. PROMINENT TOP BANNER: WHICH DAY IS CURRENTLY BEING ENTERED */}
      {/* ============================================================ */}
      <div className="bg-white rounded-2xl border-2 border-emerald-500 shadow-sm p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-all">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex flex-col items-center justify-center shadow-xs shrink-0">
            <span className="text-[10px] font-bold uppercase tracking-wider leading-none">
              {selectedDateObj.toLocaleDateString('en-US', { month: 'short' })}
            </span>
            <span className="text-xl font-black leading-none mt-0.5">
              {selectedDateObj.getDate()}
            </span>
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                Shift Day Being Entered
              </span>
              {isDateToday && (
                <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
                  Today
                </span>
              )}
              {isDateSavedInLedger ? (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Saved in Ledger</span>
                </span>
              ) : (
                <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                  Draft / Unsaved
                </span>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1 break-words">
              {dayOfWeekName}, {selectedDateObj.toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5 break-words">
              Recording daily takings, booth lease allocation, and staff payroll for this specific shift.
            </p>
          </div>
        </div>

        {/* Quick Day Navigation & Direct Shift PDF Download */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-between md:justify-end">
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => handleShiftDay(-1)}
              className="px-2.5 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors cursor-pointer flex items-center gap-1"
              title="Switch to previous day"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Prev Day</span>
            </button>
            <button
              type="button"
              onClick={() => setDate(todayStr)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer border ${
                isDateToday
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
              }`}
              title="Jump to today"
            >
              Today
            </button>
            <button
              type="button"
              onClick={() => handleShiftDay(1)}
              className="px-2.5 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors cursor-pointer flex items-center gap-1"
              title="Switch to next day"
            >
              <span className="hidden sm:inline">Next Day</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <input
            type="date"
            value={date}
            onChange={(e) => e.target.value && setDate(e.target.value)}
            className="px-3 py-1.5 text-xs font-semibold rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer shadow-xs"
            title="Choose specific date"
          />

          <button
            type="button"
            onClick={() => {
              const currentRecord: DailyRecord = {
                id: `rec-${date}`,
                date,
                bankRevenue: numBank,
                cashRevenue: numCash,
                totalCashIn,
                staffSalaries: staffList.filter((s) => s.name.trim() !== '' || s.amount > 0 || ((s.bottlesSold ?? 0) > 0)),
                totalStaffSalary,
                dailyRentSnapshot: totalDailyRent,
                totalCashOut,
                netDailyBalance,
                notes: notes.trim(),
              };
              downloadDailyShiftPDF(currentRecord, locations);
            }}
            className="px-3 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
            title="Download this shift's summary as a PDF document"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Shift PDF</span>
          </button>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 1. LOCATIONS & BOOTH RENT SETUP (Integrated into Daily)     */}
      {/* ============================================================ */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden transition-all">
        {/* Section Header */}
        <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-gradient-to-r from-emerald-50/70 via-white to-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">
                  Booth Locations & Weekly Rent Setup
                </h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                  {activeBoothCount} Active Booths
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5 font-medium">
                Booth Formula: <span className="font-mono font-bold text-emerald-800">∑ (Weekly Rent ÷ Days Used) for active booths</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
            <div className="text-right hidden sm:block">
              <div className="text-[11px] text-slate-500 font-semibold">Daily Rent on Shift ({dayOfWeekName})</div>
              <div className="text-xl font-black font-mono text-emerald-700">
                {formatCurrency(totalDailyRent)} <span className="text-xs font-normal text-slate-500">/day</span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                {activeBoothCount} booths active on {date}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowAddLocationForm(!showAddLocationForm)}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{showAddLocationForm ? 'Cancel' : 'Add Booth'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLocationsExpanded(!isLocationsExpanded)}
                className="p-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
                title={isLocationsExpanded ? 'Collapse' : 'Expand'}
              >
                {isLocationsExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        {/* Collapsible Content */}
        {isLocationsExpanded && (
          <div className="p-5 space-y-4">
            {/* Inline Add Location Form with Days & Date Picker */}
            {showAddLocationForm && (
              <form
                onSubmit={handleCreateLocation}
                className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-3.5"
              >
                <div className="text-xs font-bold text-emerald-950 uppercase tracking-wider flex items-center gap-1.5">
                  <Store className="w-4 h-4 text-emerald-600" />
                  <span>Register New AvoAddict Booth Location & Rent Allocation</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Booth / Location Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Bangsar, Sunway, KLCC"
                      value={newLocName}
                      onChange={(e) => setNewLocName(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Booth Code / Identifier
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. AA-BSR"
                      value={newLocCode}
                      onChange={(e) => setNewLocCode(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs font-mono uppercase rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Weekly Rent Amount (RM) *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      required
                      placeholder="1000.00"
                      value={newLocWeeklyRent}
                      onChange={(e) => setNewLocWeeklyRent(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Days Used / Operating (1-7) *
                    </label>
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        min="1"
                        max="7"
                        required
                        value={newLocDays}
                        onChange={(e) => setNewLocDays(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                      <div className="flex items-center gap-1">
                        {['5', '6', '7'].map((d) => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => setNewLocDays(d)}
                            className={`px-1.5 py-1 text-[10px] font-bold rounded-lg border cursor-pointer ${
                              newLocDays === d
                                ? 'bg-emerald-600 text-white border-emerald-600'
                                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                            }`}
                          >
                            {d}d
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Date Picker Operational Range */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                      <CalendarRange className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Active From (Start Date Picker - Optional)</span>
                    </label>
                    <input
                      type="date"
                      value={newLocStartDate}
                      onChange={(e) => setNewLocStartDate(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                      <CalendarRange className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Active Until (End Date Picker - Optional)</span>
                    </label>
                    <input
                      type="date"
                      value={newLocEndDate}
                      onChange={(e) => setNewLocEndDate(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-emerald-200/60">
                  <div className="text-xs font-mono text-emerald-900 flex flex-wrap items-center gap-2">
                    <span>Formula:</span>
                    <span className="font-bold">{formatCurrency(safeNum(newLocWeeklyRent))}</span>
                    <span>÷</span>
                    <span className="font-bold">{parseInt(newLocDays, 10) || 6} days</span>
                    <span>=</span>
                    <span className="px-2 py-0.5 rounded-lg bg-emerald-100 font-black text-emerald-800">
                      {formatCurrency(safeNum(newLocWeeklyRent) / (parseInt(newLocDays, 10) || 6))}/day
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddLocationForm(false)}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Save Booth Location</span>
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* Mobile Booth Cards (< sm) to fit 100% screen width without side-by-side scrolling */}
            <div className="sm:hidden space-y-3">
              {locations.map((loc) => {
                const isEditing = editingLocId === loc.id;
                const opDays = loc.operatingDays && loc.operatingDays > 0 ? loc.operatingDays : 6;
                const dailyRentShare = calculateLocationDailyRent(loc);
                const isActiveOnShift = isLocationActiveOnDate(loc, date);

                if (isEditing) {
                  return (
                    <div key={loc.id} className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-3">
                      <div className="font-bold text-xs text-emerald-900 flex items-center justify-between">
                        <span>Edit Booth Location</span>
                        <span className="font-mono text-[10px] bg-white px-2 py-0.5 rounded border border-emerald-200">
                          {loc.code}
                        </span>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Name</label>
                          <input
                            type="text"
                            value={editLocName}
                            onChange={(e) => setEditLocName(e.target.value)}
                            className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 bg-white"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Code</label>
                            <input
                              type="text"
                              value={editLocCode}
                              onChange={(e) => setEditLocCode(e.target.value)}
                              className="w-full px-2.5 py-1.5 text-xs font-mono uppercase rounded-xl border border-slate-300 bg-white"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Weekly Rent (RM)</label>
                            <input
                              type="number"
                              step="0.01"
                              value={editLocWeeklyRent}
                              onChange={(e) => setEditLocWeeklyRent(e.target.value)}
                              className="w-full px-2.5 py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-300 bg-white"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Days Used (1-7)</label>
                            <input
                              type="number"
                              min="1"
                              max="7"
                              value={editLocDays}
                              onChange={(e) => setEditLocDays(e.target.value)}
                              className="w-full px-2.5 py-1.5 text-xs font-mono text-center rounded-xl border border-slate-300 bg-white"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Calculated Daily</label>
                            <div className="px-2 py-1.5 text-xs font-mono font-bold text-emerald-800 bg-emerald-100 rounded-xl">
                              {formatCurrency(safeNum(editLocWeeklyRent) / (parseInt(editLocDays, 10) || 6))}/day
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">Start Date</label>
                            <input
                              type="date"
                              value={editLocStartDate}
                              onChange={(e) => setEditLocStartDate(e.target.value)}
                              className="w-full px-2 py-1 text-[11px] rounded-lg border border-slate-300 bg-white"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] font-semibold text-slate-600 mb-0.5">End Date</label>
                            <input
                              type="date"
                              value={editLocEndDate}
                              onChange={(e) => setEditLocEndDate(e.target.value)}
                              className="w-full px-2 py-1 text-[11px] rounded-lg border border-slate-300 bg-white"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-end gap-2 pt-1 border-t border-emerald-200">
                        <button
                          type="button"
                          onClick={() => setEditingLocId(null)}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEditLoc(loc.id, loc)}
                          className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg cursor-pointer flex items-center gap-1 shadow-xs"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Save Changes</span>
                        </button>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={loc.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      isActiveOnShift
                        ? 'bg-white border-slate-200 shadow-xs'
                        : 'bg-slate-50 border-slate-200 opacity-75'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{loc.name}</span>
                        <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                          {loc.code}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {isActiveOnShift ? (
                          <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                            Active
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-slate-500 bg-slate-200 px-2 py-0.5 rounded-full">
                            Inactive Today
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-100 text-center font-mono text-xs">
                      <div className="bg-slate-50 p-1.5 rounded-lg">
                        <div className="text-[10px] font-sans text-slate-500 uppercase font-medium">Weekly</div>
                        <div className="font-bold text-slate-800 mt-0.5">{formatCurrency(loc.weeklyRent)}</div>
                      </div>
                      <div className="bg-slate-50 p-1.5 rounded-lg">
                        <div className="text-[10px] font-sans text-slate-500 uppercase font-medium">Days/Wk</div>
                        <div className="font-bold text-slate-800 mt-0.5">{opDays} days</div>
                      </div>
                      <div className="bg-emerald-50 p-1.5 rounded-lg">
                        <div className="text-[10px] font-sans text-emerald-700 uppercase font-medium">Daily Rent</div>
                        <div className="font-bold text-emerald-700 mt-0.5">{formatCurrency(dailyRentShare)}</div>
                      </div>
                    </div>

                    {(loc.startDate || loc.endDate) && (
                      <div className="text-[11px] text-slate-500 mt-2 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>
                          Active: {loc.startDate || 'Start'} → {loc.endDate || 'Ongoing'}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-100">
                      <label className="flex items-center gap-1.5 cursor-pointer text-xs text-slate-600">
                        <input
                          type="checkbox"
                          checked={loc.isActive}
                          onChange={(e) => onUpdateLocation({ ...loc, isActive: e.target.checked })}
                          className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                        />
                        <span className="text-[11px] font-medium">Master Active</span>
                      </label>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleStartEditLoc(loc)}
                          className="px-2.5 py-1 text-xs font-bold text-slate-700 hover:text-emerald-700 bg-slate-100 hover:bg-emerald-50 rounded-lg transition-colors flex items-center gap-1"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => executeDeleteLocation(loc.id)}
                          className="px-2.5 py-1 text-xs font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Del</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs flex items-center justify-between font-semibold text-emerald-950">
                <span>Active: {activeBoothCount} of {locations.length} booths</span>
                <span className="font-mono font-bold text-emerald-700">{formatCurrency(totalDailyRent)}/day total</span>
              </div>
            </div>

            {/* Desktop / Tablet Booth Locations Table (>= sm) */}
            <div className="hidden sm:block overflow-x-auto border border-slate-200 rounded-xl table-responsive-container">
              <table className="w-full min-w-[700px] text-left text-xs">
                <thead className="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Booth Location</th>
                    <th className="py-2.5 px-3 font-semibold">Code</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Weekly Rent (RM)</th>
                    <th className="py-2.5 px-3 font-semibold text-center">Days Used</th>
                    <th className="py-2.5 px-3 font-semibold">Operating Dates</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Daily Rent (Rent ÷ Days)</th>
                    <th className="py-2.5 px-3 font-semibold text-center">Shift Status</th>
                    <th className="py-2.5 px-3 font-semibold text-center">Master Active</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {locations.map((loc) => {
                    const isEditing = editingLocId === loc.id;
                    const opDays = loc.operatingDays && loc.operatingDays > 0 ? loc.operatingDays : 6;
                    const dailyRentShare = calculateLocationDailyRent(loc);
                    const isActiveOnShift = isLocationActiveOnDate(loc, date);

                    if (isEditing) {
                      return (
                        <tr key={loc.id} className="bg-emerald-50/50">
                          <td className="py-2 px-3">
                            <input
                              type="text"
                              value={editLocName}
                              onChange={(e) => setEditLocName(e.target.value)}
                              className="w-full px-2 py-1 text-xs rounded border border-slate-300 bg-white"
                            />
                          </td>
                          <td className="py-2 px-3">
                            <input
                              type="text"
                              value={editLocCode}
                              onChange={(e) => setEditLocCode(e.target.value)}
                              className="w-20 px-2 py-1 text-xs font-mono uppercase rounded border border-slate-300 bg-white"
                            />
                          </td>
                          <td className="py-2 px-3 text-right">
                            <input
                              type="number"
                              step="0.01"
                              value={editLocWeeklyRent}
                              onChange={(e) => setEditLocWeeklyRent(e.target.value)}
                              className="w-24 px-2 py-1 text-xs font-mono text-right rounded border border-slate-300 bg-white"
                            />
                          </td>
                          <td className="py-2 px-3 text-center">
                            <input
                              type="number"
                              min="1"
                              max="7"
                              value={editLocDays}
                              onChange={(e) => setEditLocDays(e.target.value)}
                              className="w-14 px-1.5 py-1 text-xs font-mono text-center rounded border border-slate-300 bg-white"
                            />
                          </td>
                          <td className="py-2 px-3">
                            <div className="flex items-center gap-1">
                              <input
                                type="date"
                                value={editLocStartDate}
                                onChange={(e) => setEditLocStartDate(e.target.value)}
                                className="px-1 py-0.5 text-[11px] rounded border border-slate-300 bg-white"
                                title="Start Date"
                              />
                              <span className="text-slate-400">to</span>
                              <input
                                type="date"
                                value={editLocEndDate}
                                onChange={(e) => setEditLocEndDate(e.target.value)}
                                className="px-1 py-0.5 text-[11px] rounded border border-slate-300 bg-white"
                                title="End Date"
                              />
                            </div>
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700">
                            {formatCurrency(safeNum(editLocWeeklyRent) / (parseInt(editLocDays, 10) || 6))}
                          </td>
                          <td colSpan={2} className="py-2 px-3 text-center text-slate-400 text-xs">—</td>
                          <td className="py-2 px-3 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleSaveEditLoc(loc.id, loc)}
                                className="p-1 text-emerald-600 hover:text-emerald-700 cursor-pointer"
                                title="Save"
                              >
                                <Check className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => setEditingLocId(null)}
                                className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                                title="Cancel"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    }

                    return (
                      <tr key={loc.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-slate-900">{loc.name}</div>
                          {loc.managerName && (
                            <div className="text-[11px] text-slate-400">Mgr: {loc.managerName}</div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-500">{loc.code}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                          {formatCurrency(loc.weeklyRent)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="inline-block px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                            {opDays} days/wk
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 text-[11px]">
                          {loc.startDate || loc.endDate ? (
                            <div className="flex items-center gap-1 font-mono">
                              <CalendarRange className="w-3 h-3 text-emerald-600 shrink-0" />
                              <span>{loc.startDate || 'Start'} → {loc.endDate || 'Ongoing'}</span>
                            </div>
                          ) : (
                            <span className="text-slate-400">All Dates (Continuous)</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span className="font-mono font-semibold text-emerald-700">
                            {formatCurrency(dailyRentShare)}
                          </span>
                          <span className="text-[10px] text-slate-400 ml-1">/day</span>
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          {isActiveOnShift ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                              <span>Active</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-500">
                              <span>Off-date</span>
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <button
                            onClick={() => onUpdateLocation({ ...loc, isActive: !loc.isActive })}
                            className={`text-xs font-bold cursor-pointer transition-colors ${
                              loc.isActive ? 'text-emerald-600 hover:text-emerald-700' : 'text-slate-400'
                            }`}
                            title="Toggle Master Status"
                          >
                            {loc.isActive ? 'Active' : 'Disabled'}
                          </button>
                        </td>
                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleStartEditLoc(loc)}
                              className="p-1 text-slate-400 hover:text-slate-700 rounded cursor-pointer"
                              title="Edit Booth"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => executeDeleteLocation(loc.id)}
                              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                              title={`Delete ${loc.name} Booth`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                  <tr>
                    <td colSpan={2} className="py-2.5 px-3 text-slate-800">
                      Total Active for Shift ({activeBoothCount} of {locations.length} booths)
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-900">
                      {formatCurrency(totalWeeklyRent)}
                    </td>
                    <td colSpan={2} className="py-2.5 px-3 text-center text-[11px] text-slate-500 font-normal">
                      Individual days allocation: ∑ (Weekly Rent ÷ Days)
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-emerald-700 text-sm">
                      {formatCurrency(totalDailyRent)}
                      <span className="text-[10px] font-normal text-slate-500 ml-1">/day</span>
                    </td>
                    <td colSpan={3} className="py-2.5 px-3 text-right text-[11px] text-emerald-800 font-semibold">
                      Applied to {date}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* 2. DAILY ENTRY CALCULATOR & INPUTS                         */}
      {/* ============================================================ */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
              {dayOfWeekName} Shift
            </span>
            <span className="text-xs text-slate-500 font-mono">
              {date}
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 mt-1 flex items-center gap-2 break-words">
            <span>AvoAddict Daily Entry ({dayOfWeekName}, {selectedDateObj.getDate()} {selectedDateObj.toLocaleDateString('en-US', { month: 'short' })})</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 break-words">
            Log today&apos;s bank & cash takings in RM. Total daily rent is automatically pulled from active booth setup.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <input
              type="date"
              aria-label="Daily Entry Date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full sm:w-auto px-3.5 py-2 text-sm font-semibold rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer shadow-xs"
            />
          </div>
          <button
            type="button"
            onClick={() => setDate(todayStr)}
            className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer shadow-xs ${
              date === todayStr
                ? 'bg-emerald-600 text-white border-emerald-600'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            Today
          </button>
        </div>
      </div>

      {/* Main Grid: Form (Left 7 Cols) & Real-Time Calculation HUD (Right 5 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Form */}
        <form onSubmit={handleSaveEntry} className="lg:col-span-7 space-y-6">
          {/* Revenue Inputs Box */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  1. Daily Revenue Breakdown (RM)
                </h3>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-700">
                Total In: {formatCurrency(totalCashIn)}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Received in Bank (RM)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 font-mono text-xs font-bold">
                    RM
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={bankRevenue}
                    onChange={(e) => setBankRevenue(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 text-base font-mono font-bold rounded-xl border border-slate-300 bg-slate-50/50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">DuitNow QR, Cards, Touch n Go eWallet</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Received in Cash (RM)
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 font-mono text-xs font-bold">
                    RM
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    value={cashRevenue}
                    onChange={(e) => setCashRevenue(e.target.value)}
                    className="w-full pl-10 pr-3 py-2.5 text-base font-mono font-bold rounded-xl border border-slate-300 bg-slate-50/50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">Physical register till takings</p>
              </div>
            </div>
          </div>

          {/* Staff Salary & Bottle Sales Section */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  2. Staff Salaries & Bottle Sales (RM)
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <div className="hidden md:flex items-center gap-2 text-xs font-mono font-semibold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-lg">
                  <span className="text-emerald-700 font-bold">{totalBottlesSoldToday} btls sold</span>
                  <span>·</span>
                  <span>{formatCurrency(totalStaffSalary)} payroll</span>
                </div>

                {dailyRecords.length > 0 && (
                  <button
                    type="button"
                    onClick={handleCopyRecentStaffRoster}
                    className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1 transition-colors cursor-pointer"
                    title="Copy staff roster from recent entry"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Roster</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleAddStaff}
                  className="px-3 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors flex items-center gap-1 cursor-pointer border border-emerald-200"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Crew Member</span>
                </button>
              </div>
            </div>

            {/* Column Labels for wider screens */}
            {staffList.length > 0 && (
              <div className="hidden sm:flex items-center gap-2.5 px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <div className="flex-1">Staff Member Name</div>
                <div className="w-32 text-center">Bottles Sold</div>
                <div className="w-36 text-right">Wages (RM)</div>
                <div className="w-8"></div>
              </div>
            )}

            {/* Staff Rows */}
            <div className="space-y-2.5">
              {staffList.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl">
                  No staff members added for today. Click &quot;Add Crew Member&quot; to assign shifts.
                </div>
              ) : (
                staffList.map((staff) => (
                  <div
                    key={staff.id}
                    className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 p-3 bg-slate-50/70 rounded-xl border border-slate-200"
                  >
                    <div className="flex-1">
                      <label className="block sm:hidden text-[10px] font-semibold text-slate-500 mb-0.5">Staff Name</label>
                      <input
                        type="text"
                        placeholder="Staff Name (e.g. Ahmad Faiz, Kelly Tan)"
                        value={staff.name}
                        onChange={(e) => handleUpdateStaff(staff.id, 'name', e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 font-medium"
                      />
                    </div>

                    {/* Bottles Sold Field */}
                    <div className="w-full sm:w-32">
                      <label className="block sm:hidden text-[10px] font-semibold text-slate-500 mb-0.5">Bottles Sold</label>
                      <div className="relative">
                        <input
                          type="number"
                          min="0"
                          step="1"
                          placeholder="0 btls"
                          value={staff.bottlesSold === undefined || staff.bottlesSold === 0 ? '' : staff.bottlesSold}
                          onChange={(e) => handleUpdateStaff(staff.id, 'bottlesSold', e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs font-mono font-bold text-center rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                          title="Bottles sold by this staff member"
                        />
                        <span className="text-[10px] text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none font-sans hidden sm:block">
                          btls
                        </span>
                      </div>
                    </div>

                    <div className="w-full sm:w-36">
                      <label className="block sm:hidden text-[10px] font-semibold text-slate-500 mb-0.5">Wages (RM)</label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-0 pl-2 flex items-center text-slate-400 font-mono text-[11px] font-bold">
                          RM
                        </span>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0.00"
                          value={staff.amount === 0 ? '' : staff.amount}
                          onChange={(e) => handleUpdateStaff(staff.id, 'amount', e.target.value)}
                          className="w-full pl-8 pr-2 py-1.5 text-xs font-mono font-bold text-right rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        />
                      </div>
                    </div>

                    {/* FUNCTIONAL DELETE BUTTON FOR STAFF LINE */}
                    <button
                      type="button"
                      onClick={() => handleRemoveStaff(staff.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 self-center rounded-lg transition-colors cursor-pointer"
                      title="Remove crew line"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="flex items-center justify-between pt-2 text-xs text-slate-500 border-t border-slate-100">
              <span>{staffList.length} crew shifts assigned</span>
              <span className="font-mono font-bold text-slate-900">
                Staff Payroll Subtotal: {formatCurrency(totalStaffSalary)}
              </span>
            </div>
          </div>

          {/* Operational Remarks */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider">
              Shift Remarks & Daily Notes
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Bangsar and Sunway had high avocado smoothie demand; supplier delivery received."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-slate-50/50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white"
            />
          </div>

          {/* Save Action & Shift PDF Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
            <div className="flex items-center">
              {isSavedToastVisible && (
                <div className="text-xs font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Entry for {dayOfWeekName} saved to ledger!</span>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const currentRecord: DailyRecord = {
                    id: `rec-${date}`,
                    date,
                    bankRevenue: numBank,
                    cashRevenue: numCash,
                    totalCashIn,
                    staffSalaries: staffList.filter((s) => s.name.trim() !== '' || s.amount > 0 || ((s.bottlesSold ?? 0) > 0)),
                    totalStaffSalary,
                    dailyRentSnapshot: totalDailyRent,
                    totalCashOut,
                    netDailyBalance,
                    notes: notes.trim(),
                  };
                  downloadDailyShiftPDF(currentRecord, locations);
                }}
                className="w-full sm:w-auto px-4 py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                title="Download this shift summary as a PDF file"
              >
                <Download className="w-3.5 h-3.5 text-slate-600" />
                <span>Download Shift PDF</span>
              </button>

              <button
                type="button"
                onClick={() => handleSaveEntry()}
                className="w-full sm:w-auto min-h-[44px] px-6 py-2.5 text-xs sm:text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-xl shadow-md hover:shadow-lg transition-all cursor-pointer flex items-center justify-center gap-2"
                title="Save this shift entry into the permanent daily ledger"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Save Entry for {dayOfWeekName} ({date})</span>
              </button>
            </div>
          </div>
        </form>

        {/* FLOATING RECORD SAVED CONFIRMATION POPUP (Visible across all devices) */}
        {isSavedToastVisible && (
          <div className="fixed top-4 right-4 sm:top-6 sm:right-6 z-50 max-w-sm w-[92vw] bg-white rounded-2xl shadow-2xl border-2 border-emerald-500 p-4 sm:p-5 animate-in fade-in slide-in-from-top-4 duration-200">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                    <span>Record Saved!</span>
                    <span>🎉</span>
                  </h4>
                  <button
                    type="button"
                    onClick={() => setIsSavedToastVisible(false)}
                    className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
                    title="Dismiss"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs text-slate-600 mt-1">
                  Shift entry for <span className="font-semibold text-emerald-800">{dayOfWeekName}, {date}</span> has been successfully saved to the ledger.
                </p>

                {lastSavedRecord && (
                  <div className="grid grid-cols-3 gap-1.5 mt-3 pt-2.5 border-t border-slate-100 text-center text-[10px]">
                    <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                      <span className="text-slate-500 block">Total In</span>
                      <span className="font-bold text-slate-900 font-mono">{formatCurrency(lastSavedRecord.totalCashIn)}</span>
                    </div>
                    <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                      <span className="text-slate-500 block">Total Out</span>
                      <span className="font-bold text-slate-900 font-mono">{formatCurrency(lastSavedRecord.totalCashOut)}</span>
                    </div>
                    <div className={`p-1.5 rounded-lg border ${
                      lastSavedRecord.netDailyBalance >= 0
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-red-50 text-red-800 border-red-200'
                    }`}>
                      <span className="block opacity-80">Net Balance</span>
                      <span className="font-bold font-mono">{formatCurrency(lastSavedRecord.netDailyBalance)}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Right Column: Real-Time HUD */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                Auto-Calculations for {date}
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-mono font-semibold">
                Live Formula HUD
              </span>
            </div>

            {/* Total Cash In */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Total Cash In (Bank + Cash)</span>
                <span className="font-mono text-slate-400">
                  {formatCurrency(numBank)} + {formatCurrency(numCash)}
                </span>
              </div>
              <div className="text-3xl font-black font-mono text-emerald-700">
                {formatCurrency(totalCashIn)}
              </div>
            </div>

            {/* Total Cash Out Breakdown */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span>Total Cash Out</span>
                <span className="font-mono text-base text-slate-900">
                  {formatCurrency(totalCashOut)}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs space-y-2 font-mono">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span>Daily Rent ({activeBoothCount} Booths: ∑ Weekly ÷ {activeBoothCount || 1})</span>
                  </span>
                  <span className="font-bold">{formatCurrency(totalDailyRent)}</span>
                </div>
                <div className="flex items-center justify-between text-slate-700">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                    <span>Staff Salaries ({staffList.length} shifts)</span>
                  </span>
                  <span className="font-bold">{formatCurrency(totalStaffSalary)}</span>
                </div>
              </div>
            </div>

            {/* Net Daily Balance Card */}
            <div
              className={`p-4 rounded-xl border transition-colors ${
                netDailyBalance >= 0
                  ? 'bg-emerald-50/70 border-emerald-200'
                  : 'bg-red-50/70 border-red-200'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600 mb-1">
                <span>Net Daily Balance</span>
                <span className="font-mono text-[11px]">Total In − Total Out</span>
              </div>
              <div
                className={`text-3xl font-black font-mono ${
                  netDailyBalance >= 0 ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {formatCurrency(netDailyBalance)}
              </div>
              <div className="text-xs text-slate-600 mt-2 flex items-center justify-between">
                <span>Operating Margin:</span>
                <span className="font-mono font-bold text-slate-900">
                  {totalCashIn > 0 ? formatPercent(netDailyBalance / totalCashIn) : '0.0%'}
                </span>
              </div>
            </div>

            {/* Low-Margin Warning Alert */}
            {isLowMarginWarning ? (
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-amber-800">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
                  <span>Low-Margin Warning Triggered (&gt;60% Overhead)</span>
                </div>
                <p>
                  Today&apos;s daily fixed overhead (Rent + Staff: <span className="font-mono font-bold">{formatCurrency(totalCashOut)}</span>) absorbs{' '}
                  <span className="font-mono font-extrabold text-amber-800">
                    {formatPercent(expenseRatio)}
                  </span>{' '}
                  of revenue.
                </p>
                <p className="text-[11px] text-amber-700">
                  Recommendation: Review shift staffing levels or promote high-margin avocado smoothies.
                </p>
              </div>
            ) : totalCashIn > 0 ? (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Healthy operating margin ({formatPercent(1 - expenseRatio)} profit retained).</span>
              </div>
            ) : null}
          </div>

          {/* Calculation Formula Verification Callout */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 text-xs text-slate-600 space-y-1.5">
            <div className="font-bold text-slate-900 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Booth Rental Math Verification</span>
            </div>
            <p className="font-mono text-[11px] text-slate-700">
              Active Booths on {date}: {locations.filter((l) => isLocationActiveOnDate(l, date)).map((l) => `${l.name} (${formatCurrency(l.weeklyRent)} ÷ ${l.operatingDays || 6}d = ${formatCurrency(calculateLocationDailyRent(l))}/d)`).join(' + ') || 'None'}
            </p>
            <p className="font-mono text-[11px] text-emerald-800 font-bold">
              Total Shift Daily Rent = {formatCurrency(totalDailyRent)}/day
            </p>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 3. HISTORICAL DAILY LEDGER & SEARCH SYSTEM                 */}
      {/* ============================================================ */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              AvoAddict Historical Daily Ledger
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Search by staff or remarks. Download full historical ledger in Excel (.xlsx) or direct PDF (.pdf).
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <div className="relative flex-1 sm:w-56">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search staff, notes, date..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <input
              type="date"
              aria-label="Filter records from date"
              value={dateFilterStart}
              onChange={(e) => setDateFilterStart(e.target.value)}
              className="px-2 py-1.5 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none"
              title="Start Date"
            />
            <input
              type="date"
              aria-label="Filter records to date"
              value={dateFilterEnd}
              onChange={(e) => setDateFilterEnd(e.target.value)}
              className="px-2 py-1.5 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none"
              title="End Date"
            />

            {(searchQuery || dateFilterStart || dateFilterEnd) && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setDateFilterStart('');
                  setDateFilterEnd('');
                }}
                className="text-xs text-slate-500 hover:text-slate-900 underline px-1 cursor-pointer"
              >
                Clear
              </button>
            )}

            <button
              onClick={() => exportDailyLedgerToExcel(dailyRecords)}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs border border-slate-200"
              title="Download Ledger in Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              <span>Download Excel</span>
            </button>

            <button
              onClick={() => downloadDailyLedgerPDF(filteredHistory, locations)}
              className="px-3.5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Download Daily Ledger as PDF file (.pdf)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF Ledger</span>
            </button>

            {onOpenPrintModal && (
              <button
                onClick={onOpenPrintModal}
                className="px-2.5 py-1.5 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Open Printable Statement / Full Monthly Report"
              >
                <Printer className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Print</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Shift Cards (< sm) to fit 100% screen width without side-by-side scrolling */}
        <div className="sm:hidden p-4 space-y-3">
          {filteredHistory.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No historical entries match your filter.
            </div>
          ) : (
            filteredHistory
              .sort((a, b) => b.date.localeCompare(a.date))
              .map((rec) => {
                const dayName = new Date(rec.date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short' });
                const isPositive = rec.netDailyBalance >= 0;
                return (
                  <div
                    key={rec.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      rec.date === date
                        ? 'bg-emerald-50/50 border-emerald-300 ring-2 ring-emerald-500/20'
                        : 'bg-white border-slate-200 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{rec.date}</span>
                        <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          {dayName}
                        </span>
                      </div>
                      <span
                        className={`text-xs font-mono font-black px-2.5 py-1 rounded-lg border ${
                          isPositive
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                            : 'bg-red-50 text-red-700 border-red-200'
                        }`}
                      >
                        Net: {formatCurrency(rec.netDailyBalance)}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 py-2 border-y border-slate-100 font-mono text-xs">
                      <div>
                        <div className="text-[10px] font-sans text-slate-500 uppercase font-medium">Revenue (In)</div>
                        <div className="font-bold text-slate-900 mt-0.5">{formatCurrency(rec.totalCashIn)}</div>
                        <div className="text-[10px] text-slate-400 font-sans">
                          Bank {formatCurrency(rec.bankRevenue)} · Cash {formatCurrency(rec.cashRevenue)}
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] font-sans text-slate-500 uppercase font-medium">Expenses (Out)</div>
                        <div className="font-bold text-slate-800 mt-0.5">{formatCurrency(rec.totalCashOut)}</div>
                        <div className="text-[10px] text-slate-400 font-sans">
                          Rent {formatCurrency(rec.dailyRentSnapshot)} · Staff {formatCurrency(rec.totalStaffSalary)}
                        </div>
                      </div>
                    </div>

                    {rec.staffSalaries && rec.staffSalaries.length > 0 && (
                      <div className="text-[11px] text-slate-600 mt-2">
                        <div className="font-semibold text-slate-700 mb-1 flex items-center justify-between">
                          <span>Crew & Bottles Sold:</span>
                          <span className="font-mono text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                            Total: {(rec.staffSalaries || []).reduce((sum, s) => sum + (s.bottlesSold || 0), 0)} btls
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {rec.staffSalaries.map((s, idx) => (
                            <span key={idx} className="bg-slate-50 border border-slate-200 px-2 py-0.5 rounded text-[10px]">
                              <span className="font-medium text-slate-800">{s.name || 'Crew Member'}</span>
                              {s.bottlesSold !== undefined && s.bottlesSold > 0 ? (
                                <span className="font-bold text-emerald-700 ml-1">({s.bottlesSold} btls)</span>
                              ) : null}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-2 mt-2.5 pt-2 border-t border-slate-100">
                      <button
                        onClick={() => {
                          setDate(rec.date);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="px-3 py-1 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => downloadDailyShiftPDF(rec, locations)}
                        className="px-3 py-1 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Download className="w-3 h-3" />
                        <span>PDF</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => executeDeleteRecord(rec.id)}
                        className="px-2.5 py-1 text-xs font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Del</span>
                      </button>
                    </div>
                  </div>
                );
              })
          )}
        </div>

        {/* Desktop / Tablet Ledger Table (>= sm) */}
        <div className="hidden sm:block overflow-x-auto table-responsive-container">
          <table className="w-full min-w-[820px] text-left text-xs">
            <thead className="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-600 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Date</th>
                <th className="py-3 px-4 font-semibold text-right">Bank (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Cash (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Total In (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Daily Rent (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Staff Payroll (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Total Out (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Net Balance (RM)</th>
                <th className="py-3 px-4 font-semibold">Crew & Bottles Sold</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredHistory.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-400 font-sans">
                    No historical entries match your filter.
                  </td>
                </tr>
              ) : (
                filteredHistory
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .map((rec) => {
                    const isConfirmingDelete = confirmDeleteRecId === rec.id;
                    const shiftTotalBottles = (rec.staffSalaries || []).reduce((sum, s) => sum + (s.bottlesSold || 0), 0);
                    return (
                      <tr
                        key={rec.id}
                        className={`hover:bg-slate-50 transition-colors ${
                          rec.date === date ? 'bg-emerald-50/50' : ''
                        }`}
                      >
                        <td className="py-3 px-4 font-semibold font-sans text-slate-900">
                          <div>{rec.date}</div>
                          <div className="text-[10px] text-slate-400 font-normal">
                            {new Date(rec.date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short' })}
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right text-slate-600">
                          {formatCurrency(rec.bankRevenue)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-600">
                          {formatCurrency(rec.cashRevenue)}
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-slate-900">
                          {formatCurrency(rec.totalCashIn)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-500">
                          {formatCurrency(rec.dailyRentSnapshot)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-600">
                          {formatCurrency(rec.totalStaffSalary)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-800 font-medium">
                          {formatCurrency(rec.totalCashOut)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <span
                            className={`font-bold ${
                              rec.netDailyBalance >= 0 ? 'text-emerald-700' : 'text-red-600'
                            }`}
                          >
                            {formatCurrency(rec.netDailyBalance)}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-sans text-slate-600 break-words whitespace-normal min-w-[160px] max-w-[240px]">
                          {rec.staffSalaries && rec.staffSalaries.length > 0 ? (
                            <div className="space-y-1">
                              {rec.staffSalaries.map((s, idx) => (
                                <div key={idx} className="flex items-center justify-between gap-1 text-[11px]">
                                  <span className="font-medium text-slate-800 truncate">{s.name || 'Crew Member'}</span>
                                  {s.bottlesSold !== undefined && s.bottlesSold > 0 ? (
                                    <span className="font-mono text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 shrink-0">
                                      {s.bottlesSold} btls
                                    </span>
                                  ) : (
                                    <span className="text-[10px] text-slate-400">0 btls</span>
                                  )}
                                </div>
                              ))}
                              {shiftTotalBottles > 0 && (
                                <div className="text-[10px] font-bold text-emerald-800 pt-0.5 border-t border-slate-100 flex items-center justify-between">
                                  <span>Shift Total:</span>
                                  <span>{shiftTotalBottles} bottles</span>
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="text-slate-400">None</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap font-sans">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setDate(rec.date);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                              }}
                              className="px-2 py-1 text-xs text-emerald-700 font-bold hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                              title={`Edit shift for ${rec.date}`}
                            >
                              Edit
                            </button>

                            <button
                              type="button"
                              onClick={() => downloadDailyShiftPDF(rec, locations)}
                              className="px-2 py-1 text-xs text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors cursor-pointer flex items-center gap-1"
                              title={`Download PDF for ${rec.date}`}
                            >
                              <Download className="w-3 h-3" />
                              <span>PDF</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => executeDeleteRecord(rec.id)}
                              className="px-2 py-1 text-xs text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition-colors cursor-pointer flex items-center gap-1"
                              title={`Delete entry for ${rec.date}`}
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Del</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
