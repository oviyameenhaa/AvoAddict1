import React, { useMemo } from 'react';
import { BusinessLocation, DailyRecord, InventoryItem, WeeklyOwnerDraw } from '../../types';
import {
  calculateMonthlySummary,
  calculateTotalDailyRent,
  formatCurrency,
  formatPercent,
} from '../../utils/calculations';
import {
  Calendar,
  Printer,
  TrendingUp,
  Building2,
  Users,
  Package,
  User,
  ArrowUpRight,
  ArrowDownRight,
  FileSpreadsheet,
  Download,
} from 'lucide-react';
import { exportMonthlyReportToExcel } from '../../utils/storage';
import { downloadMonthlyReportPDF } from '../../utils/pdfGenerator';

interface MonthlySummaryTabProps {
  locations: BusinessLocation[];
  dailyRecords: DailyRecord[];
  weeklyOwnerDraws: WeeklyOwnerDraw[];
  inventoryItems: InventoryItem[];
  selectedMonth: string;
  setSelectedMonth: (m: string) => void;
  onOpenPrintModal: () => void;
}

export const MonthlySummaryTab: React.FC<MonthlySummaryTabProps> = ({
  locations,
  dailyRecords,
  weeklyOwnerDraws,
  inventoryItems,
  selectedMonth,
  setSelectedMonth,
  onOpenPrintModal,
}) => {
  const summary = useMemo(() => {
    return calculateMonthlySummary(
      selectedMonth,
      dailyRecords,
      locations,
      weeklyOwnerDraws,
      inventoryItems
    );
  }, [selectedMonth, dailyRecords, locations, weeklyOwnerDraws, inventoryItems]);

  const [yearStr, monthStr] = selectedMonth.split('-');
  const monthName = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1).toLocaleDateString(
    'en-US',
    { month: 'long', year: 'numeric' }
  );

  const activeBooths = locations.filter((l) => l.isActive);
  const totalWeeklyRent = activeBooths.reduce((acc, l) => acc + l.weeklyRent, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner / Month Selector & Download Buttons */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>AvoAddict Monthly P&L Statement</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Full comprehensive Profit & Loss across sales, booth leases ({activeBooths.length} locations), crew payroll, inventory, and founder draws.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            type="month"
            aria-label="Select Accounting Month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none cursor-pointer"
          />

          {/* Download Excel Button */}
          <button
            onClick={() => exportMonthlyReportToExcel(selectedMonth, summary, summary.records, locations)}
            className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            title="Download Monthly Report in Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span>Download Excel (.xlsx)</span>
          </button>

          {/* Download PDF Button */}
          <button
            onClick={() => downloadMonthlyReportPDF(selectedMonth, summary, summary.records, locations, inventoryItems, weeklyOwnerDraws)}
            className="px-3.5 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
            title="Download Monthly Report PDF to your device"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Gross Revenue */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Total Monthly Sales</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-black font-mono text-slate-900">
            {formatCurrency(summary.totalRevenue)}
          </div>
          <div className="text-xs text-slate-500 mt-2 flex items-center justify-between font-mono">
            <span>Bank: {formatCurrency(summary.totalBankRevenue)}</span>
            <span>Cash: {formatCurrency(summary.totalCashRevenue)}</span>
          </div>
        </div>

        {/* Total Operating Expenses */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Total Operating Overhead</span>
            <Package className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-3xl font-black font-mono text-slate-900">
            {formatCurrency(summary.totalExpenses)}
          </div>
          <div className="text-xs text-slate-500 mt-2">
            Rent + Staff + Draw + Inventory
          </div>
        </div>

        {/* Monthly Net Profit */}
        <div
          className={`p-5 rounded-2xl border shadow-sm ${
            summary.monthlyNetProfit >= 0
              ? 'bg-emerald-50/70 border-emerald-200'
              : 'bg-red-50/70 border-red-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Monthly Net Profit</span>
            {summary.monthlyNetProfit >= 0 ? (
              <ArrowUpRight className="w-4 h-4 text-emerald-600" />
            ) : (
              <ArrowDownRight className="w-4 h-4 text-red-600" />
            )}
          </div>
          <div
            className={`text-3xl font-black font-mono ${
              summary.monthlyNetProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
            }`}
          >
            {formatCurrency(summary.monthlyNetProfit)}
          </div>
          <div className="text-xs text-slate-600 mt-2 font-mono">
            Net Margin:{' '}
            <span className="font-bold text-slate-900">
              {formatPercent(summary.profitMargin)}
            </span>
          </div>
        </div>

        {/* Days Logged Progress */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            Operating Coverage
          </div>
          <div className="text-3xl font-black font-mono text-slate-900">
            {summary.daysLogged} Days
          </div>
          <div className="text-xs text-slate-500 mt-2">
            Active logged shifts in {monthName}
          </div>
        </div>
      </div>

      {/* Formal P&L Statement Structure */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">
              AvoAddict Statement of Profit and Loss — {monthName}
            </h3>
          </div>
          <span className="text-xs font-mono font-bold text-slate-600">Currency: Ringgit Malaysia (RM)</span>
        </div>

        <div className="divide-y divide-slate-100 text-sm">
          {/* Section: Revenue */}
          <div className="p-5 space-y-3 bg-white">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              1. Operating Sales Revenue
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-slate-700">
                <span className="pl-3">Bank Receipts (DuitNow QR, Cards, Touch n Go eWallet)</span>
                <span className="font-mono font-semibold">{formatCurrency(summary.totalBankRevenue)}</span>
              </div>
              <div className="flex items-center justify-between text-slate-700">
                <span className="pl-3">Cash Counter Receipts</span>
                <span className="font-mono font-semibold">{formatCurrency(summary.totalCashRevenue)}</span>
              </div>
              <div className="flex items-center justify-between font-bold text-slate-900 pt-1 border-t border-slate-200">
                <span>Total Monthly Gross Revenue (A)</span>
                <span className="font-mono text-base text-emerald-700">
                  {formatCurrency(summary.totalRevenue)}
                </span>
              </div>
            </div>
          </div>

          {/* Section: Operating Expenses */}
          <div className="p-5 space-y-3 bg-white">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              2. Operating Expenses & Direct Costs
            </div>

            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-slate-700">
                <span className="pl-3 flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Booth Locations Rental Overhead (∑ Daily Rent Recorded)</span>
                </span>
                <span className="font-mono font-semibold">{formatCurrency(summary.totalRental)}</span>
              </div>

              <div className="flex items-center justify-between text-slate-700">
                <span className="pl-3 flex items-center gap-2">
                  <Users className="w-3.5 h-3.5 text-slate-400" />
                  <span>Crew Staff Salaries & Shift Payroll</span>
                </span>
                <span className="font-mono font-semibold">{formatCurrency(summary.totalStaffSalaries)}</span>
              </div>

              <div className="flex items-center justify-between text-slate-700">
                <span className="pl-3 flex items-center gap-2">
                  <Package className="w-3.5 h-3.5 text-slate-400" />
                  <span>Inventory Direct Goods (Avocado Hass, Wakame, Botol, NSK, Susu)</span>
                </span>
                <span className="font-mono font-semibold">{formatCurrency(summary.totalInventoryCost)}</span>
              </div>

              <div className="flex items-center justify-between text-slate-700">
                <span className="pl-3 flex items-center gap-2">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>Founder&apos;s Draw / &quot;My Salary&quot;</span>
                </span>
                <span className="font-mono font-semibold">{formatCurrency(summary.totalOwnersDraw)}</span>
              </div>

              <div className="flex items-center justify-between font-bold text-slate-900 pt-2 border-t border-slate-200">
                <span>Total Operating Overhead & Costs (B)</span>
                <span className="font-mono text-base text-slate-900">
                  {formatCurrency(summary.totalExpenses)}
                </span>
              </div>
            </div>
          </div>

          {/* Section: Net Income */}
          <div className="p-5 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-base font-black text-slate-900">
                Monthly Net Profit = Total Revenue (A) − Total Costs (B)
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Formula: Revenue − (Booth Rental + Staff Salaries + Founder Draw + Inventory Cost)
              </p>
            </div>

            <div className="text-right">
              <div
                className={`text-2xl sm:text-3xl font-black font-mono ${
                  summary.monthlyNetProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
                }`}
              >
                {formatCurrency(summary.monthlyNetProfit)}
              </div>
              <div className="text-xs font-mono font-bold text-slate-600">
                Net Profit Margin: {formatPercent(summary.profitMargin)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
