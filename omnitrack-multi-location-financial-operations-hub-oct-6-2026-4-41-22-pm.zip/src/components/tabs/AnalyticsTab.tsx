import React, { useEffect, useRef, useState, useMemo } from 'react';
import { BusinessLocation, DailyRecord, InventoryItem, WeeklyOwnerDraw } from '../../types';
import {
  calculateDailyRent,
  formatCurrency,
  formatPercent,
  safeNum,
} from '../../utils/calculations';
import {
  TrendingUp,
  AlertTriangle,
  Award,
  DollarSign,
  PieChart as PieIcon,
  BarChart3,
  Building2,
  ShieldAlert,
  FileSpreadsheet,
  Printer,
  Download,
  Trophy,
  Flame,
  Users,
} from 'lucide-react';
import { Chart, registerables } from 'chart.js';
import { exportMonthlyReportToExcel } from '../../utils/storage';
import { calculateMonthlySummary } from '../../utils/calculations';
import { downloadMonthlyReportPDF } from '../../utils/pdfGenerator';

Chart.register(...registerables);

interface AnalyticsTabProps {
  locations: BusinessLocation[];
  dailyRecords: DailyRecord[];
  weeklyOwnerDraws: WeeklyOwnerDraw[];
  inventoryItems: InventoryItem[];
  selectedMonth: string;
  onOpenPrintModal: () => void;
  onNavigateToDaily: (date: string) => void;
}

export const AnalyticsTab: React.FC<AnalyticsTabProps> = ({
  locations,
  dailyRecords,
  weeklyOwnerDraws,
  inventoryItems,
  selectedMonth,
  onOpenPrintModal,
  onNavigateToDaily,
}) => {
  const [timeframe, setTimeframe] = useState<'month' | 'all'>('month');

  const lineChartRef = useRef<HTMLCanvasElement | null>(null);
  const donutChartRef = useRef<HTMLCanvasElement | null>(null);
  const expenseChartRef = useRef<HTMLCanvasElement | null>(null);

  const lineChartInstance = useRef<Chart | null>(null);
  const donutChartInstance = useRef<Chart | null>(null);
  const expenseChartInstance = useRef<Chart | null>(null);

  const activeRecords = useMemo(() => {
    if (timeframe === 'month') {
      return dailyRecords.filter((r) => r.date.startsWith(selectedMonth));
    }
    return dailyRecords;
  }, [dailyRecords, timeframe, selectedMonth]);

  const totalRevenue = useMemo(() => {
    return activeRecords.reduce((sum, r) => sum + safeNum(r.totalCashIn), 0);
  }, [activeRecords]);

  const totalDailyRentLogged = useMemo(() => {
    return activeRecords.reduce((sum, r) => sum + safeNum(r.dailyRentSnapshot), 0);
  }, [activeRecords]);

  const totalStaffPayroll = useMemo(() => {
    return activeRecords.reduce((sum, r) => sum + safeNum(r.totalStaffSalary), 0);
  }, [activeRecords]);

  const totalInventoryExpense = useMemo(() => {
    const items = timeframe === 'month'
      ? inventoryItems.filter((i) => !i.purchaseDate || i.purchaseDate.startsWith(selectedMonth))
      : inventoryItems;
    return items.reduce((sum, i) => sum + safeNum(i.totalCost), 0);
  }, [inventoryItems, timeframe, selectedMonth]);

  const totalDraws = useMemo(() => {
    const draws = timeframe === 'month'
      ? weeklyOwnerDraws.filter((d) => d.startDate.startsWith(selectedMonth) || d.endDate.startsWith(selectedMonth))
      : weeklyOwnerDraws;
    return draws.reduce((sum, d) => sum + safeNum(d.amount), 0);
  }, [weeklyOwnerDraws, timeframe, selectedMonth]);

  const totalExpenses = totalDailyRentLogged + totalStaffPayroll + totalInventoryExpense + totalDraws;
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? netProfit / totalRevenue : 0;

  const expenseCategories = [
    { name: 'Crew Payroll', amount: totalStaffPayroll, color: '#3B82F6' },
    { name: 'Branch Rent Overhead', amount: totalDailyRentLogged, color: '#059669' },
    { name: 'Inventory & Fresh Stock', amount: totalInventoryExpense, color: '#F59E0B' },
    { name: "Founder's Draw", amount: totalDraws, color: '#8B5CF6' },
  ].sort((a, b) => b.amount - a.amount);

  const topExpenseCategory = expenseCategories[0] || { name: 'Branch Rent Overhead', amount: 0 };

  // Best & Worst Location Analysis
  const locationAnalysis = useMemo(() => {
    if (locations.length === 0) return { bestLoc: null, worstLoc: null, locStats: [] };

    const locStats = locations.map((loc) => {
      let locRev = 0;
      activeRecords.forEach((r) => {
        if (r.locationBreakdowns && r.locationBreakdowns.length > 0) {
          const b = r.locationBreakdowns.find((lb) => lb.locationId === loc.id);
          if (b) {
            locRev += safeNum(b.bankRevenue) + safeNum(b.cashRevenue);
          }
        } else {
          const totalRent = locations.reduce((sum, l) => sum + l.weeklyRent, 0);
          const ratio = totalRent > 0 ? loc.weeklyRent / totalRent : 1 / locations.length;
          locRev += r.totalCashIn * ratio;
        }
      });

      const daysCount = activeRecords.length > 0 ? activeRecords.length : 26;
      const activeBooths = locations.filter((l) => l.isActive);
      const boothDivisor = activeBooths.length > 0 ? activeBooths.length : 1;
      const dailyRent = safeNum(loc.weeklyRent) / boothDivisor;
      const totalLocRent = dailyRent * daysCount;
      const rentBurdenRatio = locRev > 0 ? totalLocRent / locRev : 1;

      return {
        location: loc,
        revenue: locRev,
        rentCost: totalLocRent,
        rentBurdenRatio,
      };
    });

    const sortedByRevenue = [...locStats].sort((a, b) => b.revenue - a.revenue);
    const sortedByBurden = [...locStats].sort((a, b) => b.rentBurdenRatio - a.rentBurdenRatio);

    const bestLoc = sortedByRevenue[0] || null;
    const worstLoc = sortedByBurden[0] || null;

    return { bestLoc, worstLoc, locStats };
  }, [locations, activeRecords]);

  // Low-Margin Warnings Scanner (>60% daily overhead)
  const lowMarginDays = useMemo(() => {
    return activeRecords.filter((r) => {
      return r.totalCashIn > 0 && r.totalCashOut / r.totalCashIn > 0.60;
    });
  }, [activeRecords]);

  // Staff Bottle Sales Analysis (Which staff has highest bottle sales)
  const staffBottleAnalysis = useMemo(() => {
    const staffMap = new Map<
      string,
      { name: string; totalBottles: number; totalWages: number; shiftsCount: number }
    >();

    activeRecords.forEach((r) => {
      (r.staffSalaries || []).forEach((s) => {
        const cleanName = (s.name || '').trim();
        if (!cleanName) return;
        const existing = staffMap.get(cleanName) || {
          name: cleanName,
          totalBottles: 0,
          totalWages: 0,
          shiftsCount: 0,
        };
        existing.totalBottles += safeNum(s.bottlesSold) || 0;
        existing.totalWages += safeNum(s.amount) || 0;
        existing.shiftsCount += 1;
        staffMap.set(cleanName, existing);
      });
    });

    const totalBottlesSold = Array.from(staffMap.values()).reduce((sum, s) => sum + s.totalBottles, 0);

    const staffList = Array.from(staffMap.values())
      .map((s) => ({
        ...s,
        avgBottlesPerShift: s.shiftsCount > 0 ? (s.totalBottles / s.shiftsCount).toFixed(1) : '0.0',
        percentOfTotal: totalBottlesSold > 0 ? ((s.totalBottles / totalBottlesSold) * 100).toFixed(1) : '0.0',
      }))
      .sort((a, b) => {
        if (b.totalBottles !== a.totalBottles) {
          return b.totalBottles - a.totalBottles;
        }
        return b.shiftsCount - a.shiftsCount;
      });

    const topStaff = staffList.length > 0 && staffList[0].totalBottles > 0 ? staffList[0] : (staffList[0] || null);

    return { topStaff, staffList, totalBottlesSold };
  }, [activeRecords]);

  // Chart Rendering (Bright theme colors)
  useEffect(() => {
    const textColor = '#475569';
    const gridColor = '#F1F5F9';

    const sorted = [...activeRecords].sort((a, b) => a.date.localeCompare(b.date));
    const labels = sorted.map((r) => r.date.substring(5)); // MM-DD
    const revenueData = sorted.map((r) => r.totalCashIn);
    const expenseData = sorted.map((r) => r.totalCashOut);
    const profitData = sorted.map((r) => r.netDailyBalance);

    // 1. Line/Bar Chart: Daily Revenue vs Expenses
    if (lineChartRef.current) {
      if (lineChartInstance.current) {
        lineChartInstance.current.destroy();
      }

      const ctx = lineChartRef.current.getContext('2d');
      if (ctx) {
        lineChartInstance.current = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: labels.length > 0 ? labels : ['No Data'],
            datasets: [
              {
                type: 'bar',
                label: 'Gross Sales (RM)',
                data: revenueData.length > 0 ? revenueData : [0],
                backgroundColor: 'rgba(16, 185, 129, 0.85)',
                borderRadius: 4,
                order: 2,
              },
              {
                type: 'bar',
                label: 'Direct Overhead (RM)',
                data: expenseData.length > 0 ? expenseData : [0],
                backgroundColor: 'rgba(239, 68, 68, 0.75)',
                borderRadius: 4,
                order: 3,
              },
              {
                type: 'line',
                label: 'Daily Net Profit (RM)',
                data: profitData.length > 0 ? profitData : [0],
                borderColor: '#2563EB',
                borderWidth: 2.5,
                pointBackgroundColor: '#2563EB',
                pointRadius: 3,
                tension: 0.3,
                order: 1,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                labels: {
                  color: textColor,
                  font: { family: 'Plus Jakarta Sans', size: 12, weight: 600 },
                },
              },
              tooltip: {
                callbacks: {
                  label: (context) => ` ${context.dataset.label}: ${formatCurrency(context.parsed.y)}`,
                },
              },
            },
            scales: {
              x: {
                grid: { color: gridColor },
                ticks: { color: textColor, font: { family: 'JetBrains Mono', size: 10 } },
              },
              y: {
                grid: { color: gridColor },
                ticks: {
                  color: textColor,
                  font: { family: 'JetBrains Mono', size: 10 },
                  callback: (value) => `RM ${value}`,
                },
              },
            },
          },
        });
      }
    }

    // 2. Donut Chart: Revenue Breakdown by Location
    if (donutChartRef.current) {
      if (donutChartInstance.current) {
        donutChartInstance.current.destroy();
      }

      const locLabels = locationAnalysis.locStats.map((s) => s.location.name);
      const locRevenues = locationAnalysis.locStats.map((s) => s.revenue);
      const colors = ['#059669', '#2563EB', '#8B5CF6', '#F59E0B', '#EC4899'];

      const ctx = donutChartRef.current.getContext('2d');
      if (ctx) {
        donutChartInstance.current = new Chart(ctx, {
          type: 'doughnut',
          data: {
            labels: locLabels.length > 0 ? locLabels : ['No Locations'],
            datasets: [
              {
                data: locRevenues.length > 0 ? locRevenues : [1],
                backgroundColor: colors.slice(0, locLabels.length),
                borderWidth: 2,
                borderColor: '#FFFFFF',
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  color: textColor,
                  font: { family: 'Plus Jakarta Sans', size: 11, weight: 600 },
                  boxWidth: 12,
                },
              },
              tooltip: {
                callbacks: {
                  label: (context) => ` ${context.label}: ${formatCurrency(context.parsed)}`,
                },
              },
            },
            cutout: '68%',
          },
        });
      }
    }

    // 3. Donut Chart: Expense Composition
    if (expenseChartRef.current) {
      if (expenseChartInstance.current) {
        expenseChartInstance.current.destroy();
      }

      const ctx = expenseChartRef.current.getContext('2d');
      if (ctx) {
        expenseChartInstance.current = new Chart(ctx, {
          type: 'doughnut',
          data: {
            labels: expenseCategories.map((c) => c.name),
            datasets: [
              {
                data: expenseCategories.map((c) => c.amount),
                backgroundColor: expenseCategories.map((c) => c.color),
                borderWidth: 2,
                borderColor: '#FFFFFF',
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  color: textColor,
                  font: { family: 'Plus Jakarta Sans', size: 11, weight: 600 },
                  boxWidth: 12,
                },
              },
              tooltip: {
                callbacks: {
                  label: (context) => ` ${context.label}: ${formatCurrency(context.parsed)}`,
                },
              },
            },
            cutout: '68%',
          },
        });
      }
    }

    return () => {
      if (lineChartInstance.current) lineChartInstance.current.destroy();
      if (donutChartInstance.current) donutChartInstance.current.destroy();
      if (expenseChartInstance.current) expenseChartInstance.current.destroy();
    };
  }, [activeRecords, locationAnalysis, expenseCategories]);

  return (
    <div className="space-y-6">
      {/* Top Banner / Timeframe Controls */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <span>AvoAddict Analytics & Operational Insights</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time branch telemetry, rent efficiency ratios in RM, and automated low-margin alerts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setTimeframe('month')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                timeframe === 'month'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              This Month ({selectedMonth})
            </button>
            <button
              onClick={() => setTimeframe('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                timeframe === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Time
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const summary = calculateMonthlySummary(
                  selectedMonth,
                  dailyRecords,
                  locations,
                  weeklyOwnerDraws,
                  inventoryItems
                );
                exportMonthlyReportToExcel(selectedMonth, summary, summary.records, locations);
              }}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Download Report in Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              <span>Download Excel</span>
            </button>
            <button
              onClick={() => {
                const summary = calculateMonthlySummary(
                  selectedMonth,
                  dailyRecords,
                  locations,
                  weeklyOwnerDraws,
                  inventoryItems
                );
                downloadMonthlyReportPDF(selectedMonth, summary, summary.records, locations, inventoryItems, weeklyOwnerDraws);
              }}
              className="px-3.5 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
              title="Download PDF Financial Report to your device"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* 5 Summary Metrics Cards (Bright style, no cutting off words) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {/* Total Revenue */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Total Gross Revenue</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-black font-mono text-slate-900">
            {formatCurrency(totalRevenue)}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-mono">
            {timeframe === 'month' ? `Filtered to ${selectedMonth}` : 'Cumulative all logged dates'}
          </div>
        </div>

        {/* Net Profit & Margin % */}
        <div
          className={`p-5 rounded-2xl border shadow-sm ${
            netProfit >= 0 ? 'bg-emerald-50/70 border-emerald-200' : 'bg-red-50/70 border-red-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Net Operating Profit</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div
            className={`text-3xl font-black font-mono ${
              netProfit >= 0 ? 'text-emerald-700' : 'text-red-600'
            }`}
          >
            {formatCurrency(netProfit)}
          </div>
          <div className="text-xs text-slate-600 mt-2 font-mono">
            Profit Margin:{' '}
            <span className="font-bold text-slate-900">
              {formatPercent(profitMargin)}
            </span>
          </div>
        </div>

        {/* Top Performing Location (No cutting off words) */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Top Performing Branch</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-lg font-bold text-slate-900 break-words">
            {locationAnalysis.bestLoc ? locationAnalysis.bestLoc.location.name : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-mono break-words">
            {locationAnalysis.bestLoc
              ? `${formatCurrency(locationAnalysis.bestLoc.revenue)} gross sales`
              : 'No location data'}
          </div>
        </div>

        {/* Highest Bottle Sales (Staff Performance) */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Highest Bottle Sales</span>
            <Trophy className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-lg font-bold text-slate-900 break-words">
            {staffBottleAnalysis.topStaff && staffBottleAnalysis.topStaff.totalBottles > 0
              ? staffBottleAnalysis.topStaff.name
              : '—'}
          </div>
          <div className="text-xs mt-2 font-mono break-words">
            {staffBottleAnalysis.topStaff && staffBottleAnalysis.topStaff.totalBottles > 0 ? (
              <span className="text-emerald-700 font-bold">
                {staffBottleAnalysis.topStaff.totalBottles} bottles ({staffBottleAnalysis.topStaff.shiftsCount} {staffBottleAnalysis.topStaff.shiftsCount === 1 ? 'shift' : 'shifts'})
              </span>
            ) : (
              <span className="text-slate-400">No staff sales logged</span>
            )}
          </div>
        </div>

        {/* Top Expense Category (No cutting off words) */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <span>Top Expense Category</span>
            <DollarSign className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-lg font-bold text-slate-900 break-words">
            {topExpenseCategory.name}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-mono break-words">
            {formatCurrency(topExpenseCategory.amount)} (
            {totalExpenses > 0 ? formatPercent(topExpenseCategory.amount / totalExpenses) : '0%'} of costs)
          </div>
        </div>
      </div>

      {/* Smart Business Insights: Best/Worst Location & Low-Margin Scanner */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Best & Worst Location Analysis Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              AvoAddict Branch Rent Efficiency
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            {locationAnalysis.bestLoc && (
              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-emerald-900">
                  <span className="flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Top Sales Generator: {locationAnalysis.bestLoc.location.name}</span>
                  </span>
                  <span className="font-mono">{formatCurrency(locationAnalysis.bestLoc.revenue)}</span>
                </div>
                <p className="text-slate-600">
                  Weekly Lease: <span className="font-mono font-semibold">{formatCurrency(locationAnalysis.bestLoc.location.weeklyRent)}</span> · Rent-to-Sales Ratio:{' '}
                  <span className="font-mono font-bold text-emerald-800">
                    {formatPercent(locationAnalysis.bestLoc.rentBurdenRatio)}
                  </span>
                </p>
              </div>
            )}

            {locationAnalysis.worstLoc && (
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 space-y-1">
                <div className="flex items-center justify-between font-bold text-amber-900">
                  <span className="flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    <span>Highest Rent Overhead: {locationAnalysis.worstLoc.location.name}</span>
                  </span>
                  <span className="font-mono">{formatCurrency(locationAnalysis.worstLoc.location.weeklyRent)}/wk</span>
                </div>
                <p className="text-slate-600">
                  Sales: <span className="font-mono font-semibold">{formatCurrency(locationAnalysis.worstLoc.revenue)}</span> · Rent absorbs{' '}
                  <span className="font-mono font-bold text-amber-800">
                    {formatPercent(locationAnalysis.worstLoc.rentBurdenRatio)}
                  </span>{' '}
                  of store earnings.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Low-Margin Scanner */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Low-Margin Scanner (&gt;60% Overhead)
              </h3>
            </div>
            <span
              className={`text-xs px-2.5 py-0.5 rounded-full font-mono font-bold ${
                lowMarginDays.length > 0
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {lowMarginDays.length} Alert {lowMarginDays.length === 1 ? 'Day' : 'Days'}
            </span>
          </div>

          <div className="space-y-2 text-xs">
            {lowMarginDays.length === 0 ? (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800">
                All logged days maintained overhead costs below 60% of revenue. Excellent operational efficiency!
              </div>
            ) : (
              <div className="max-h-40 overflow-y-auto space-y-2 pr-1">
                {lowMarginDays.slice(0, 5).map((d) => {
                  const ratio = d.totalCashOut / d.totalCashIn;
                  return (
                    <div
                      key={d.id}
                      className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between"
                    >
                      <div>
                        <span className="font-bold text-slate-900">{d.date}</span>
                        <span className="text-slate-500 ml-2">
                          (Sales: {formatCurrency(d.totalCashIn)}, Overhead: {formatCurrency(d.totalCashOut)})
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-amber-700">
                          {formatPercent(ratio)}
                        </span>
                        <button
                          onClick={() => onNavigateToDaily(d.date)}
                          className="text-xs text-emerald-700 font-semibold hover:underline cursor-pointer"
                        >
                          Review
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            <p className="text-[11px] text-slate-400">
              Rule: If daily rent + staff payroll exceeds 60% of daily sales, the system flags the date for management review.
            </p>
          </div>
        </div>
      </div>

      {/* Staff Bottle Sales Performance & Leaderboard Section */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center font-bold">
              <Trophy className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <span>Staff Bottle Sales Performance & Rankings</span>
              </h3>
              <p className="text-xs text-slate-500">
                Which staff has the highest bottle sales and operational selling volume.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono font-semibold">
            <span className="px-3 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold">
              {staffBottleAnalysis.totalBottlesSold} Total Bottles Sold
            </span>
            <span className="px-3 py-1 rounded-lg bg-slate-100 text-slate-700">
              {staffBottleAnalysis.staffList.length} Staff on Roster
            </span>
          </div>
        </div>

        {/* Top Performer Champion Spotlight Card */}
        {staffBottleAnalysis.topStaff && staffBottleAnalysis.topStaff.totalBottles > 0 ? (
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-50 via-emerald-50/50 to-white border-2 border-amber-300 shadow-xs relative overflow-hidden">
            <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-32 h-32 bg-amber-200/30 rounded-full blur-2xl pointer-events-none" />

            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center shadow-md shrink-0">
                  <Trophy className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 font-sans">
                      Top Bottle Seller
                    </span>
                  </div>
                  <h4 className="text-lg sm:text-xl font-black text-slate-900 mt-0.5">
                    {staffBottleAnalysis.topStaff.name}
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Generated <span className="font-bold text-emerald-800 font-mono">{staffBottleAnalysis.topStaff.percentOfTotal}%</span> of all store bottle volume in this period.
                  </p>
                </div>
              </div>

              {/* Champion Quick Stats Pills */}
              <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
                <div className="bg-white/90 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-amber-200 shadow-2xs text-center min-w-[90px]">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total Sold</div>
                  <div className="text-base font-black font-mono text-emerald-700">
                    {staffBottleAnalysis.topStaff.totalBottles} <span className="text-xs font-sans font-semibold">btls</span>
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-slate-200 shadow-2xs text-center min-w-[90px]">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Avg / Shift</div>
                  <div className="text-base font-black font-mono text-slate-900">
                    {staffBottleAnalysis.topStaff.avgBottlesPerShift} <span className="text-xs font-sans font-semibold">btls</span>
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-slate-200 shadow-2xs text-center min-w-[90px]">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Shifts Logged</div>
                  <div className="text-base font-black font-mono text-slate-900">
                    {staffBottleAnalysis.topStaff.shiftsCount}
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-slate-200 shadow-2xs text-center min-w-[90px]">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Total Wages</div>
                  <div className="text-base font-black font-mono text-slate-900">
                    {formatCurrency(staffBottleAnalysis.topStaff.totalWages)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-slate-400" />
              <span>No bottle sales recorded for this period yet. Staff sales logged in Daily Entry will appear here.</span>
            </div>
          </div>
        )}

        {/* Full Staff Leaderboard Table */}
        {staffBottleAnalysis.staffList.length > 0 && (
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Staff Sales Ranking & Efficiency Breakdown
            </div>

            {/* Responsive Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs min-w-[580px]">
                <thead>
                  <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 text-[11px] font-bold uppercase tracking-wider">
                    <th className="py-2.5 px-3.5 w-16 text-center">Rank</th>
                    <th className="py-2.5 px-3.5">Staff Member</th>
                    <th className="py-2.5 px-3.5 text-right">Bottles Sold</th>
                    <th className="py-2.5 px-3.5 text-center">Volume Share</th>
                    <th className="py-2.5 px-3.5 text-center">Shifts</th>
                    <th className="py-2.5 px-3.5 text-right">Avg btls / Shift</th>
                    <th className="py-2.5 px-3.5 text-right">Total Wages</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {staffBottleAnalysis.staffList.map((staff, idx) => {
                    const isTop = idx === 0 && staff.totalBottles > 0;
                    return (
                      <tr
                        key={staff.name}
                        className={`hover:bg-slate-50/80 transition-colors ${
                          isTop ? 'bg-amber-50/40 font-medium' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3.5 text-center font-bold">
                          {idx === 0 && staff.totalBottles > 0 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-100 text-amber-800 text-xs">
                              🥇
                            </span>
                          ) : idx === 1 && staff.totalBottles > 0 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-200 text-slate-800 text-xs">
                              🥈
                            </span>
                          ) : idx === 2 && staff.totalBottles > 0 ? (
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-100 text-amber-900 text-xs">
                              🥉
                            </span>
                          ) : (
                            <span className="text-slate-400 font-mono">#{idx + 1}</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3.5 font-bold text-slate-900">
                          <div className="flex items-center gap-1.5">
                            <span>{staff.name}</span>
                            {isTop && (
                              <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded border border-amber-300">
                                Top Seller
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-2.5 px-3.5 text-right font-mono font-bold text-emerald-800 text-sm">
                          {staff.totalBottles} <span className="text-[11px] font-normal text-slate-500 font-sans">btls</span>
                        </td>
                        <td className="py-2.5 px-3.5 text-center">
                          <div className="flex items-center gap-2 justify-center max-w-[120px] mx-auto">
                            <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                              <div
                                className={`h-full rounded-full ${
                                  isTop ? 'bg-amber-500' : 'bg-emerald-500'
                                }`}
                                style={{ width: `${Math.min(100, parseFloat(staff.percentOfTotal) || 0)}%` }}
                              />
                            </div>
                            <span className="text-[10px] font-mono font-semibold text-slate-600">
                              {staff.percentOfTotal}%
                            </span>
                          </div>
                        </td>
                        <td className="py-2.5 px-3.5 text-center font-mono text-slate-700">
                          {staff.shiftsCount}
                        </td>
                        <td className="py-2.5 px-3.5 text-right font-mono font-semibold text-slate-900">
                          {staff.avgBottlesPerShift}
                        </td>
                        <td className="py-2.5 px-3.5 text-right font-mono text-slate-700">
                          {formatCurrency(staff.totalWages)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Visual Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Bar/Line Chart */}
        <div className="lg:col-span-8 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Daily Sales vs. Expenses & Net Balance (RM)
              </h3>
            </div>
            <span className="text-xs font-mono font-semibold text-slate-400">Chart.js Engine</span>
          </div>

          <div className="h-72 w-full relative">
            <canvas ref={lineChartRef} />
          </div>
        </div>

        {/* Right: Revenue by Location Donut & Expense Donut */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-emerald-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Sales Share by Branch (RM)
              </h3>
            </div>
            <div className="h-48 w-full relative">
              <canvas ref={donutChartRef} />
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-blue-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Cost & Expense Distribution (RM)
              </h3>
            </div>
            <div className="h-48 w-full relative">
              <canvas ref={expenseChartRef} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
