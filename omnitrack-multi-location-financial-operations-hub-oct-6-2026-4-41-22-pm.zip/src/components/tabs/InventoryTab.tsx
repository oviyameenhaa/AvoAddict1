import React, { useState, useMemo } from 'react';
import { InventoryItem } from '../../types';
import { formatCurrency, formatNumber, safeNum } from '../../utils/calculations';
import {
  Package,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Search,
  ShoppingBag,
  FileSpreadsheet,
  Download,
} from 'lucide-react';
import { exportInventoryToExcel } from '../../utils/storage';
import { downloadInventoryPDF } from '../../utils/pdfGenerator';

interface InventoryTabProps {
  inventoryItems: InventoryItem[];
  onAddInventoryItem: (item: Omit<InventoryItem, 'id' | 'totalCost'>) => void;
  onUpdateInventoryItem: (item: InventoryItem) => void;
  onDeleteInventoryItem: (id: string) => void;
  selectedMonth: string;
  setSelectedMonth: (month: string) => void;
}

export const InventoryTab: React.FC<InventoryTabProps> = ({
  inventoryItems,
  onAddInventoryItem,
  onUpdateInventoryItem,
  onDeleteInventoryItem,
  selectedMonth,
  setSelectedMonth,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Functional deletion confirmation (No window.confirm!)
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  // New item form state
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Fresh Produce');
  const [quantityStr, setQuantityStr] = useState('');
  const [unit, setUnit] = useState('kg');
  const [unitCostStr, setUnitCostStr] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(`${selectedMonth}-01`);

  // Edit item inline state
  const [editName, setEditName] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editQuantity, setEditQuantity] = useState('');
  const [editUnit, setEditUnit] = useState('');
  const [editUnitCost, setEditUnitCost] = useState('');

  const monthlyItems = useMemo(() => {
    return inventoryItems.filter(
      (item) => !item.purchaseDate || item.purchaseDate.startsWith(selectedMonth)
    );
  }, [inventoryItems, selectedMonth]);

  const totalMonthlyInventoryCost = useMemo(() => {
    return monthlyItems.reduce((sum, item) => sum + safeNum(item.totalCost), 0);
  }, [monthlyItems]);

  const categories = useMemo(() => {
    const set = new Set<string>();
    monthlyItems.forEach((item) => {
      if (item.category) set.add(item.category);
    });
    return Array.from(set);
  }, [monthlyItems]);

  const filteredItems = useMemo(() => {
    return monthlyItems.filter((item) => {
      const matchSearch =
        !searchQuery.trim() ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = selectedCategory === 'ALL' || item.category === selectedCategory;
      return matchSearch && matchCat;
    });
  }, [monthlyItems, searchQuery, selectedCategory]);

  const handleStartEdit = (item: InventoryItem) => {
    setEditingId(item.id);
    setEditName(item.name);
    setEditCategory(item.category);
    setEditQuantity(item.quantity.toString());
    setEditUnit(item.unit);
    setEditUnitCost(item.unitCost.toString());
  };

  const handleCancelEdit = () => {
    setEditingId(null);
  };

  const handleSaveEdit = (id: string, originalItem: InventoryItem) => {
    const qty = safeNum(editQuantity);
    const unitCost = safeNum(editUnitCost);
    const totalCost = Number((qty * unitCost).toFixed(2));

    onUpdateInventoryItem({
      ...originalItem,
      id,
      name: editName.trim() || 'Untitled Item',
      category: editCategory.trim() || 'General',
      quantity: qty,
      unit: editUnit.trim() || 'units',
      unitCost,
      totalCost,
    });
    setEditingId(null);
  };

  const handleCreateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const qty = safeNum(quantityStr);
    const unitCost = safeNum(unitCostStr);

    onAddInventoryItem({
      name: name.trim(),
      category: category.trim() || 'General Supplies',
      quantity: qty,
      unit: unit.trim() || 'pcs',
      unitCost,
      purchaseDate: purchaseDate || `${selectedMonth}-01`,
      isDefault: false,
    });

    setName('');
    setQuantityStr('');
    setUnitCostStr('');
    setShowAddForm(false);
  };

  const executeDeleteItem = (id: string) => {
    onDeleteInventoryItem(id);
    setConfirmDeleteId(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Monthly Inventory HUD */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Total Monthly Inventory Cost Card */}
        <div className="p-5 rounded-2xl bg-white border border-emerald-200 shadow-sm">
          <div className="flex items-center justify-between text-emerald-800 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">
              Total Monthly Inventory Cost
            </span>
            <Package className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-black font-mono text-emerald-700">
            {formatCurrency(totalMonthlyInventoryCost)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Linked directly into AvoAddict Monthly P&L Net Profit calculation
          </div>
        </div>

        {/* Item Count & Varieties */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Active Inventory SKUs</span>
            <ShoppingBag className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-3xl font-black font-mono text-slate-900">
            {monthlyItems.length}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Core baseline: Avocado, Wakame, Botol, NSK, Susu
          </div>
        </div>

        {/* Month Selector */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            Accounting Month
          </div>
          <div className="flex items-center gap-2">
            <input
              type="month"
              aria-label="Accounting Month"
              value={selectedMonth}
              onChange={(e) => {
                setSelectedMonth(e.target.value);
                setPurchaseDate(`${e.target.value}-01`);
              }}
              className="w-full px-3 py-2 text-sm font-semibold rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            />
          </div>
          <div className="text-[11px] text-slate-400 mt-2 font-mono">
            Purchases accounted in {selectedMonth}
          </div>
        </div>
      </div>

      {/* Main Inventory Ledger & Stock Manager */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              AvoAddict Inventory & Supply Cost Tracker
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Hass avocados, wakame packs, PET bottles, NSK dressing, and fresh milk in RM.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <div className="relative flex-1 sm:w-44">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search items..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none"
              />
            </div>

            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              aria-label="Filter items by category"
              className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:outline-none cursor-pointer"
            >
              <option value="ALL">All Categories</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <button
              onClick={() => exportInventoryToExcel(monthlyItems, selectedMonth)}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Download Inventory as Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              <span>Export Excel</span>
            </button>

            <button
              onClick={() => downloadInventoryPDF(monthlyItems, selectedMonth)}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Download Inventory Cost Report as PDF"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Download PDF</span>
            </button>

            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{showAddForm ? 'Cancel' : 'Add Item'}</span>
            </button>
          </div>
        </div>

        {/* Add Inventory Form Collapse */}
        {showAddForm && (
          <form
            onSubmit={handleCreateItem}
            className="p-5 bg-emerald-50/50 border-b border-emerald-100 space-y-3"
          >
            <div className="text-xs font-bold text-emerald-900 uppercase tracking-wider flex items-center gap-1.5">
              <Plus className="w-3.5 h-3.5 text-emerald-600" />
              <span>Register New Inventory Purchase</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
              <div className="lg:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Item Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Avocado, Wakame, Botol, NSK, Susu"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none"
                >
                  <option value="Fresh Produce">Fresh Produce</option>
                  <option value="Pantry & Specialty">Pantry & Specialty</option>
                  <option value="Packaging">Packaging</option>
                  <option value="Core Ingredient">Core Ingredient</option>
                  <option value="Dairy">Dairy</option>
                  <option value="Beverage Supply">Beverage Supply</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Quantity *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  placeholder="50"
                  value={quantityStr}
                  onChange={(e) => setQuantityStr(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-mono font-bold rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Unit
                </label>
                <input
                  type="text"
                  placeholder="kg / pcs / liters"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Unit Cost (RM) *
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-2.5 flex items-center text-slate-400 font-mono text-[11px] font-bold">
                    RM
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    placeholder="12.50"
                    value={unitCostStr}
                    onChange={(e) => setUnitCostStr(e.target.value)}
                    className="w-full pl-8 pr-2 py-1.5 text-xs font-mono font-bold rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="text-xs font-mono text-slate-700">
                Auto Total Cost:{' '}
                <span className="font-bold text-emerald-700 text-sm">
                  {formatCurrency(safeNum(quantityStr) * safeNum(unitCostStr))}
                </span>{' '}
                ({safeNum(quantityStr)} {unit || 'units'} × {formatCurrency(safeNum(unitCostStr))})
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1 text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs cursor-pointer"
                >
                  Save Item
                </button>
              </div>
            </div>
          </form>
        )}

        {/* Mobile Inventory Cards (< sm) to fit 100% screen width without side-by-side scrolling */}
        <div className="sm:hidden p-4 space-y-3">
          {filteredItems.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No inventory records found for {selectedMonth}. Click &quot;Add Item&quot; to log stock.
            </div>
          ) : (
            filteredItems.map((item) => {
              const isEditing = editingId === item.id;
              if (isEditing) {
                return (
                  <div key={item.id} className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-300 space-y-2.5">
                    <div className="font-bold text-xs text-emerald-900">Edit Stock Item</div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Item Name</label>
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 bg-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Category</label>
                        <input
                          type="text"
                          value={editCategory}
                          onChange={(e) => setEditCategory(e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Quantity</label>
                        <input
                          type="number"
                          step="0.01"
                          value={editQuantity}
                          onChange={(e) => setEditQuantity(e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-300 bg-white"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Unit (e.g. kg)</label>
                        <input
                          type="text"
                          value={editUnit}
                          onChange={(e) => setEditUnit(e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 bg-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">Unit Cost (RM)</label>
                        <input
                          type="number"
                          step="0.01"
                          value={editUnitCost}
                          onChange={(e) => setEditUnitCost(e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs font-mono font-bold rounded-xl border border-slate-300 bg-white"
                        />
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-1 border-t border-emerald-200">
                      <span className="font-mono text-xs font-bold text-emerald-800">
                        Total: {formatCurrency(safeNum(editQuantity) * safeNum(editUnitCost))}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleCancelEdit}
                          className="px-3 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(item.id, item)}
                          className="px-3 py-1 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg cursor-pointer"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  </div>
                );
              }

              return (
                <div key={item.id} className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-sm text-slate-900">{item.name}</span>
                      {item.isDefault && (
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                          Core
                        </span>
                      )}
                    </div>
                    <span className="text-xs font-mono font-black text-emerald-700">
                      {formatCurrency(item.totalCost)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 font-mono">
                    <span className="font-sans text-[11px] text-slate-600">{item.category}</span>
                    <span>
                      {formatNumber(item.quantity, 1)} {item.unit} @ {formatCurrency(item.unitCost)}
                    </span>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => handleStartEdit(item)}
                      className="px-2.5 py-1 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => executeDeleteItem(item.id)}
                      className="px-2.5 py-1 text-xs font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Inventory Items Table (>= sm) */}
        <div className="hidden sm:block overflow-x-auto table-responsive-container">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[11px] uppercase tracking-wider text-slate-600 border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 font-semibold">Item Name</th>
                <th className="py-3 px-4 font-semibold">Category</th>
                <th className="py-3 px-4 font-semibold text-right">Quantity</th>
                <th className="py-3 px-4 font-semibold">Unit</th>
                <th className="py-3 px-4 font-semibold text-right">Unit Cost (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Total Cost (RM)</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-400 font-sans">
                    No inventory records found for {selectedMonth}. Click &quot;Add Item&quot; to log stock.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const isEditing = editingId === item.id;
                  const isConfirmingDelete = confirmDeleteId === item.id;

                  if (isEditing) {
                    return (
                      <tr key={item.id} className="bg-emerald-50/50">
                        <td className="py-3 px-4 font-sans">
                          <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded border border-slate-300 bg-white"
                          />
                        </td>
                        <td className="py-3 px-4 font-sans">
                          <input
                            type="text"
                            value={editCategory}
                            onChange={(e) => setEditCategory(e.target.value)}
                            className="w-full px-2 py-1 text-xs rounded border border-slate-300 bg-white"
                          />
                        </td>
                        <td className="py-3 px-4 text-right">
                          <input
                            type="number"
                            step="0.01"
                            value={editQuantity}
                            onChange={(e) => setEditQuantity(e.target.value)}
                            className="w-20 px-2 py-1 text-xs font-mono text-right rounded border border-slate-300 bg-white"
                          />
                        </td>
                        <td className="py-3 px-4 font-sans">
                          <input
                            type="text"
                            value={editUnit}
                            onChange={(e) => setEditUnit(e.target.value)}
                            className="w-16 px-2 py-1 text-xs rounded border border-slate-300 bg-white"
                          />
                        </td>
                        <td className="py-3 px-4 text-right">
                          <input
                            type="number"
                            step="0.01"
                            value={editUnitCost}
                            onChange={(e) => setEditUnitCost(e.target.value)}
                            className="w-20 px-2 py-1 text-xs font-mono text-right rounded border border-slate-300 bg-white"
                          />
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-emerald-700">
                          {formatCurrency(safeNum(editQuantity) * safeNum(editUnitCost))}
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap font-sans">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => handleSaveEdit(item.id, item)}
                              className="p-1 text-emerald-600 hover:text-emerald-700 cursor-pointer"
                              title="Save"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                              title="Cancel"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3.5 px-4 font-sans">
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <span>{item.name}</span>
                          {item.isDefault && (
                            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                              Core
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-sans text-slate-500">
                        {item.category}
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                        {formatNumber(item.quantity, 1)}
                      </td>
                      <td className="py-3.5 px-4 font-sans text-slate-500">
                        {item.unit}
                      </td>
                      <td className="py-3.5 px-4 text-right text-slate-600">
                        {formatCurrency(item.unitCost)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-bold text-slate-900">
                        {formatCurrency(item.totalCost)}
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap font-sans">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleStartEdit(item)}
                            className="p-1 text-slate-400 hover:text-slate-700 rounded cursor-pointer"
                            title="Edit"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => executeDeleteItem(item.id)}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                            title={`Delete ${item.name}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {filteredItems.length > 0 && (
              <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                <tr>
                  <td colSpan={5} className="py-3 px-4 font-sans text-slate-900">
                    Total Monthly Inventory Cost ({selectedMonth})
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-emerald-700 text-sm">
                    {formatCurrency(totalMonthlyInventoryCost)}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};
