export interface BusinessLocation {
  id: string;
  name: string;
  code: string;
  weeklyRent: number; // Weekly Rent in RM
  operatingDays?: number; // Days used/operating per week (e.g., 1-7 days, default 6)
  startDate?: string; // Date picker: when booth lease/operations begin (YYYY-MM-DD)
  endDate?: string; // Date picker: when booth lease/operations end (YYYY-MM-DD)
  dailyRent?: number; // Calculated daily share in RM (weeklyRent / operatingDays)
  managerName?: string;
  isActive: boolean;
}

export interface StaffSalaryLine {
  id: string;
  name: string;
  role?: string;
  amount: number; // in RM
  bottlesSold?: number; // Number of bottles sold by this staff member
  locationId?: string;
}

export interface LocationRevenueBreakdown {
  locationId: string;
  locationName: string;
  bankRevenue: number;
  cashRevenue: number;
  notes?: string;
}

export interface DailyRecord {
  id: string;
  date: string; // YYYY-MM-DD
  locationId?: string;
  locationBreakdowns?: LocationRevenueBreakdown[];
  bankRevenue: number; // in RM
  cashRevenue: number; // in RM
  totalCashIn: number; // in RM
  staffSalaries: StaffSalaryLine[];
  totalStaffSalary: number; // in RM
  dailyRentSnapshot: number; // Total Daily Rent in RM: (Sum of Weekly Rents) / (Locations Count)
  totalCashOut: number; // dailyRentSnapshot + totalStaffSalary in RM
  netDailyBalance: number; // totalCashIn - totalCashOut in RM
  notes?: string;
}

export interface WeeklyOwnerDraw {
  weekKey: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  amount: number; // in RM
  notes?: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  unitCost: number; // in RM
  totalCost: number; // quantity * unitCost in RM
  purchaseDate: string; // YYYY-MM-DD
  isDefault?: boolean;
  locationId?: string;
}

export type ActiveTab = 'daily' | 'weekly' | 'monthly' | 'inventory' | 'analytics';

export interface AppState {
  locations: BusinessLocation[];
  dailyRecords: DailyRecord[];
  weeklyOwnerDraws: WeeklyOwnerDraw[];
  inventoryItems: InventoryItem[];
}
