import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { BusinessLocation, DailyRecord, InventoryItem, WeeklyOwnerDraw } from '../types';
import { MonthlySummaryData, WeeklySummaryData, formatCurrency, formatNumber, safeNum } from './calculations';

/**
 * Cross-device reliable PDF file download.
 * Generates an in-memory blob and triggers a simulated download anchor,
 * working reliably on iOS Safari, Android, Chrome, and sandboxed iframes.
 */
export const savePdfDoc = (doc: jsPDF, filename: string): void => {
  try {
    const blob = doc.output('blob');
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    link.rel = 'noopener noreferrer';
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
      URL.revokeObjectURL(blobUrl);
    }, 1500);
  } catch (err) {
    console.warn('Direct blob download fallback, calling doc.save():', err);
    try {
      doc.save(filename);
    } catch (saveErr) {
      console.error('doc.save error:', saveErr);
    }
  }
};

/**
 * Downloads a comprehensive, professional monthly financial statement as an actual .pdf file.
 */
export const downloadMonthlyReportPDF = (
  month: string,
  summary: MonthlySummaryData,
  records: DailyRecord[],
  locations: BusinessLocation[],
  inventoryItems: InventoryItem[],
  weeklyOwnerDraws: WeeklyOwnerDraw[]
): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const [yearStr, monthStr] = month.split('-');
  const monthDate = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1);
  const monthName = monthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  // 1. Header & Title Block
  doc.setFillColor(5, 150, 105); // Emerald-600
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 60, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('AvoAddict', 40, 36);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.text('Financial & Operations Statement (RM)', 40, 50);

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`Period: ${monthName}`, doc.internal.pageSize.getWidth() - 40, 36, { align: 'right' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated: ${new Date().toLocaleDateString('en-MY')}`, doc.internal.pageSize.getWidth() - 40, 50, { align: 'right' });

  // 2. Executive Summary KPIs Box
  let startY = 80;
  doc.setTextColor(30, 41, 59); // Slate-800
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('1. Executive Financial Summary', 40, startY);

  const kpiData = [
    [
      { content: 'Total Gross Revenue', styles: { fontStyle: 'bold' } },
      formatCurrency(summary.totalRevenue),
      { content: 'Total Overhead Expenses', styles: { fontStyle: 'bold' } },
      formatCurrency(summary.totalExpenses),
    ],
    [
      { content: '• Bank Collections', styles: { textColor: [100, 116, 139] } },
      formatCurrency(summary.totalBankRevenue),
      { content: '• Active Booth Leases', styles: { textColor: [100, 116, 139] } },
      formatCurrency(summary.totalRental),
    ],
    [
      { content: '• Cash Collections', styles: { textColor: [100, 116, 139] } },
      formatCurrency(summary.totalCashRevenue),
      { content: '• Crew Payroll', styles: { textColor: [100, 116, 139] } },
      formatCurrency(summary.totalStaffSalaries),
    ],
    [
      { content: 'Operating Days Logged', styles: { textColor: [100, 116, 139] } },
      `${summary.daysLogged} days`,
      { content: '• Inventory & Supplies', styles: { textColor: [100, 116, 139] } },
      formatCurrency(summary.totalInventoryCost),
    ],
    [
      { content: 'Net Profit Margin %', styles: { fontStyle: 'bold' } },
      `${(summary.profitMargin * 100).toFixed(1)}%`,
      { content: '• Owner Salary / Draw', styles: { textColor: [100, 116, 139] } },
      formatCurrency(summary.totalOwnersDraw),
    ],
    [
      { content: 'MONTHLY NET PROFIT', styles: { fontStyle: 'bold', fillColor: [240, 253, 244], textColor: [4, 120, 87] } },
      { content: formatCurrency(summary.monthlyNetProfit), styles: { fontStyle: 'bold', fillColor: [240, 253, 244], textColor: [4, 120, 87] } },
      { content: '', styles: { fillColor: [240, 253, 244] } },
      { content: '', styles: { fillColor: [240, 253, 244] } },
    ],
  ];

  autoTable(doc, {
    startY: startY + 10,
    head: [],
    body: kpiData as any,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 4 },
    margin: { left: 40, right: 40 },
  });

  // 3. Active Booth Setup Section
  const activeBooths = locations.filter((l) => l.isActive);
  const totalWeeklyRent = activeBooths.reduce((acc, l) => acc + safeNum(l.weeklyRent), 0);
  const boothCount = activeBooths.length;
  const boothDailyRent = boothCount > 0 ? totalWeeklyRent / boothCount : 0;

  const currentY = (doc as any).lastAutoTable.finalY + 15;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('2. Active Booth Lease Model & Rent Breakdown', 40, currentY);

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Formula: (${formatCurrency(totalWeeklyRent)} total weekly rent) ÷ ${boothCount} booths = ${formatCurrency(boothDailyRent)} / day`, 40, currentY + 12);

  const boothRows = activeBooths.map((b) => [
    b.name,
    b.code,
    b.managerName || '—',
    formatCurrency(b.weeklyRent),
    `${formatCurrency(safeNum(b.weeklyRent) / (boothCount || 1))} / day`,
  ]);

  autoTable(doc, {
    startY: currentY + 18,
    head: [['Booth Location', 'Code', 'Manager', 'Weekly Rent (RM)', 'Daily Share (RM)']],
    body: boothRows,
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42], fontSize: 8.5 },
    styles: { fontSize: 8, cellPadding: 3.5 },
    margin: { left: 40, right: 40 },
  });

  // 4. Daily Shift Ledger Section
  const nextY = (doc as any).lastAutoTable.finalY + 15;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text(`3. Daily Shift Ledger (${records.length} Recorded Shifts)`, 40, nextY);

  const ledgerRows = [...records]
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((r) => {
      const d = new Date(r.date + 'T00:00:00');
      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
      return [
        `${r.date} (${dayName})`,
        formatCurrency(r.bankRevenue),
        formatCurrency(r.cashRevenue),
        formatCurrency(r.totalCashIn),
        formatCurrency(r.dailyRentSnapshot),
        formatCurrency(r.totalStaffSalary),
        formatCurrency(r.totalCashOut),
        formatCurrency(r.netDailyBalance),
        r.staffSalaries?.map((s) => s.name || 'Staff').join(', ') || 'None',
      ];
    });

  autoTable(doc, {
    startY: nextY + 8,
    head: [['Date (Day)', 'Bank (RM)', 'Cash (RM)', 'Total In (RM)', 'Rent (RM)', 'Payroll (RM)', 'Total Out (RM)', 'Net Balance (RM)', 'Crew On Duty']],
    body: ledgerRows.length > 0 ? ledgerRows : [['No shifts logged for this month.', '', '', '', '', '', '', '', '']],
    theme: 'grid',
    headStyles: { fillColor: [5, 150, 105], fontSize: 7.5 },
    styles: { fontSize: 7, cellPadding: 3 },
    columnStyles: {
      0: { cellWidth: 70 },
      8: { cellWidth: 100 },
    },
    margin: { left: 40, right: 40 },
  });

  // Footer / Page numbers
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `AvoAddict Sdn. Bhd. · Page ${i} of ${pageCount} · Generated for management accounts`,
      doc.internal.pageSize.getWidth() / 2,
      doc.internal.pageSize.getHeight() - 20,
      { align: 'center' }
    );
  }

  // Trigger file download directly into the user's downloads folder
  savePdfDoc(doc, `AvoAddict_Financial_Report_${month}.pdf`);
};

/**
 * Downloads a single Daily Shift entry as an actual .pdf file.
 */
export const downloadDailyShiftPDF = (
  record: DailyRecord,
  locations: BusinessLocation[]
): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const d = new Date(record.date + 'T00:00:00');
  const dayName = d.toLocaleDateString('en-US', { weekday: 'long' });
  const fullDateStr = d.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // Header Banner
  doc.setFillColor(5, 150, 105);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 60, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('AvoAddict Daily Shift Report', 40, 36);

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.text(`Shift Day: ${dayName} (${record.date})`, 40, 50);

  // Content
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(`Shift Overview for ${fullDateStr}`, 40, 90);

  const shiftData = [
    ['Metric', 'Amount (RM)', 'Notes'],
    ['Bank Collections', formatCurrency(record.bankRevenue), 'Electronic payments & transfers'],
    ['Cash Collections', formatCurrency(record.cashRevenue), 'Physical cash drawer takings'],
    ['TOTAL CASH IN', formatCurrency(record.totalCashIn), 'Total gross sales for the day'],
    ['Daily Rent Overhead', formatCurrency(record.dailyRentSnapshot), 'Booth lease allocation'],
    ['Staff Payroll Overhead', formatCurrency(record.totalStaffSalary), `${record.staffSalaries?.length || 0} crew shifts logged`],
    ['TOTAL CASH OUT', formatCurrency(record.totalCashOut), 'Rent + Staff payroll'],
    ['NET DAILY BALANCE', formatCurrency(record.netDailyBalance), record.netDailyBalance >= 0 ? 'Profitable shift' : 'Negative balance'],
  ];

  autoTable(doc, {
    startY: 105,
    head: [shiftData[0]],
    body: shiftData.slice(1),
    theme: 'grid',
    headStyles: { fillColor: [15, 23, 42], fontSize: 9 },
    styles: { fontSize: 8.5, cellPadding: 5 },
    margin: { left: 40, right: 40 },
  });

  // Crew Roster Table
  const crewY = (doc as any).lastAutoTable.finalY + 20;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Crew on Duty & Shift Salaries', 40, crewY);

  const crewRows = (record.staffSalaries || []).map((s) => [
    s.name || 'Crew Member',
    `${s.bottlesSold || 0} btls`,
    formatCurrency(s.amount),
  ]);

  autoTable(doc, {
    startY: crewY + 10,
    head: [['Crew Member', 'Bottles Sold', 'Daily Salary (RM)']],
    body: crewRows.length > 0 ? crewRows : [['No crew assigned for this date', '', '']],
    theme: 'striped',
    headStyles: { fillColor: [5, 150, 105], fontSize: 8.5 },
    styles: { fontSize: 8, cellPadding: 4 },
    margin: { left: 40, right: 40 },
  });

  if (record.notes) {
    const notesY = (doc as any).lastAutoTable.finalY + 20;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('Shift Notes & Remarks:', 40, notesY);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(record.notes, 40, notesY + 15, { maxWidth: doc.internal.pageSize.getWidth() - 80 });
  }

  savePdfDoc(doc, `AvoAddict_Daily_Shift_${record.date}.pdf`);
};

/**
 * Downloads a Weekly Financial Report as an actual .pdf file.
 */
export const downloadWeeklyReportPDF = (
  startDate: string,
  endDate: string,
  summary: WeeklySummaryData,
  records: DailyRecord[],
  locations: BusinessLocation[]
): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  // Header Banner
  doc.setFillColor(5, 150, 105);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 60, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('AvoAddict Weekly Financial Report', 40, 36);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Week: ${startDate} to ${endDate}`, 40, 50);

  doc.text(`Generated: ${new Date().toLocaleDateString('en-MY')}`, doc.internal.pageSize.getWidth() - 40, 45, { align: 'right' });

  // Summary Metrics Table
  doc.setTextColor(30, 41, 59);
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Weekly Financial Summary (RM)', 40, 85);

  const weeklyData = [
    ['Metric', 'Amount (RM)'],
    ['Total Weekly Revenue', formatCurrency(summary.totalWeeklyRevenue)],
    ['Total Weekly Rental (Active Booths)', formatCurrency(summary.totalWeeklyRent)],
    ['Total Staff Payroll', formatCurrency(summary.totalStaffSalary)],
    ["Owner Salary / Draw", formatCurrency(summary.ownersDraw)],
    ['Total Weekly Overhead', formatCurrency(summary.totalWeeklyRent + summary.totalStaffSalary + summary.ownersDraw)],
    ['WEEKLY NET PROFIT', formatCurrency(summary.netProfit)],
    ['Net Profit Margin %', `${(summary.profitMargin * 100).toFixed(1)}%`],
    ['Active Working Days Logged', `${summary.daysLogged} days`],
  ];

  autoTable(doc, {
    startY: 95,
    head: [['Weekly Metric', 'Amount (RM)']],
    body: weeklyData.slice(1),
    theme: 'grid',
    headStyles: { fillColor: [15, 23, 42], fontSize: 8.5 },
    styles: { fontSize: 8, cellPadding: 4 },
    margin: { left: 40, right: 40 },
  });

  // Daily Shifts within Week
  const daysY = (doc as any).lastAutoTable.finalY + 15;
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.text('Daily Shifts in Week', 40, daysY);

  const weekRows = records.map((r) => {
    const d = new Date(r.date + 'T00:00:00');
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    return [
      `${r.date} (${dayName})`,
      formatCurrency(r.bankRevenue),
      formatCurrency(r.cashRevenue),
      formatCurrency(r.totalCashIn),
      formatCurrency(r.dailyRentSnapshot),
      formatCurrency(r.totalStaffSalary),
      formatCurrency(r.totalCashOut),
      formatCurrency(r.netDailyBalance),
    ];
  });

  autoTable(doc, {
    startY: daysY + 8,
    head: [['Date (Day)', 'Bank (RM)', 'Cash (RM)', 'Total In (RM)', 'Rent (RM)', 'Payroll (RM)', 'Total Out (RM)', 'Net Balance (RM)']],
    body: weekRows.length > 0 ? weekRows : [['No shifts logged for this week period.', '', '', '', '', '', '', '']],
    theme: 'striped',
    headStyles: { fillColor: [5, 150, 105], fontSize: 7.5 },
    styles: { fontSize: 7, cellPadding: 3 },
    margin: { left: 40, right: 40 },
  });

  savePdfDoc(doc, `AvoAddict_Weekly_Report_${startDate}.pdf`);
};

/**
 * Downloads the full Daily Operational Ledger as an actual .pdf file.
 */
export const downloadDailyLedgerPDF = (
  records: DailyRecord[],
  locations: BusinessLocation[]
): void => {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'pt',
    format: 'a4',
  });

  // Header Banner
  doc.setFillColor(5, 150, 105);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 60, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('AvoAddict Operational Daily Ledger', 40, 36);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated: ${new Date().toLocaleDateString('en-MY')} · ${records.length} total shifts recorded`, doc.internal.pageSize.getWidth() - 40, 50, { align: 'right' });

  const rows = records.map((r) => {
    const d = new Date(r.date + 'T00:00:00');
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const crewSummary = (r.staffSalaries || [])
      .map((s) => `${s.name} (${formatCurrency(s.amount)})`)
      .join(', ') || '—';

    return [
      `${r.date} (${dayName})`,
      formatCurrency(r.bankRevenue),
      formatCurrency(r.cashRevenue),
      formatCurrency(r.totalCashIn),
      formatCurrency(r.dailyRentSnapshot),
      formatCurrency(r.totalStaffSalary),
      formatCurrency(r.totalCashOut),
      formatCurrency(r.netDailyBalance),
      crewSummary,
      r.notes || '—',
    ];
  });

  autoTable(doc, {
    startY: 80,
    head: [['Date (Day)', 'Bank (RM)', 'Cash (RM)', 'Total In', 'Daily Rent', 'Staff Payroll', 'Total Out', 'Net Balance', 'Crew Logged', 'Shift Notes']],
    body: rows.length > 0 ? rows : [['No daily shifts logged yet.', '', '', '', '', '', '', '', '', '']],
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42], fontSize: 8 },
    styles: { fontSize: 7, cellPadding: 3.5 },
    margin: { left: 40, right: 40 },
  });

  savePdfDoc(doc, `AvoAddict_Daily_Ledger_${new Date().toISOString().split('T')[0]}.pdf`);
};

/**
 * Downloads an Inventory & Supplies Cost Report as an actual .pdf file.
 */
export const downloadInventoryPDF = (
  items: InventoryItem[],
  month: string
): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4',
  });

  const [yearStr, monthStr] = month.split('-');
  const monthDate = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1);
  const monthName = monthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  doc.setFillColor(5, 150, 105);
  doc.rect(0, 0, doc.internal.pageSize.getWidth(), 60, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text('AvoAddict Inventory & Cost Report', 40, 36);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Accounting Month: ${monthName} (${month})`, 40, 50);

  const totalCost = items.reduce((acc, i) => acc + safeNum(i.totalCost), 0);

  const rows = items.map((i) => [
    i.name,
    i.category,
    `${formatNumber(i.quantity, 1)} ${i.unit}`,
    formatCurrency(i.unitCost),
    formatCurrency(i.totalCost),
    i.purchaseDate || '—',
  ]);

  autoTable(doc, {
    startY: 85,
    head: [['Item Name', 'Category', 'Quantity', 'Unit Cost (RM)', 'Total Cost (RM)', 'Purchase Date']],
    body: rows.length > 0 ? rows : [['No inventory items recorded for this month.', '', '', '', '', '']],
    foot: [['TOTAL INVENTORY COST', '', '', '', formatCurrency(totalCost), '']],
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42], fontSize: 8.5 },
    footStyles: { fillColor: [241, 245, 249], textColor: [15, 23, 42], fontStyle: 'bold' },
    styles: { fontSize: 8, cellPadding: 4 },
    margin: { left: 40, right: 40 },
  });

  savePdfDoc(doc, `AvoAddict_Inventory_${month}.pdf`);
};
