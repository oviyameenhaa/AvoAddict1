import { BusinessLocation, DailyRecord, InventoryItem, WeeklyOwnerDraw } from '../types';

export const safeNum = (val: unknown): number => {
  if (typeof val === 'number') {
    return isNaN(val) || !isFinite(val) ? 0 : val;
  }
  if (typeof val === 'string') {
    const cleaned = val.replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) || !isFinite(parsed) ? 0 : parsed;
  }
  return 0;
};

export const formatCurrency = (val: number | undefined | null): string => {
  const num = safeNum(val);
  const formatted = num.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `RM ${formatted}`;
};

export const formatNumber = (val: number | undefined | null, decimals = 2): string => {
  const num = safeNum(val);
  return num.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
};

export const formatPercent = (decimal: number | undefined | null): string => {
  const num = safeNum(decimal);
  return `${(num * 100).toFixed(1)}%`;
};

export const isLocationActiveOnDate = (loc: BusinessLocation, dateStr?: string): boolean => {
  if (!loc.isActive) return false;
  if (!dateStr) return true;
  if (loc.startDate && dateStr < loc.startDate) return false;
  if (loc.endDate && dateStr > loc.endDate) return false;
  return true;
};

export const calculateLocationDailyRent = (loc: BusinessLocation): number => {
  const days = safeNum(loc.operatingDays) > 0 ? safeNum(loc.operatingDays) : 6;
  return Number((safeNum(loc.weeklyRent) / days).toFixed(2));
};

export const calculateDailyRent = (weeklyRent: number, divisor: number = 6): number => {
  const d = divisor > 0 ? divisor : 1;
  return Number((safeNum(weeklyRent) / d).toFixed(2));
};

// Booth Business Model Daily Rent Formula:
// Supports booth rent divided by number of days used (e.g. 5, 6, or 7 days)
// Sums the daily rent share of all active booths operating on the given date
export const calculateTotalDailyRent = (
  locations: BusinessLocation[],
  customDivisor?: number,
  dateStr?: string
): number => {
  if (!locations || locations.length === 0) return 0;
  const activeLocations = locations.filter((loc) => isLocationActiveOnDate(loc, dateStr));
  if (activeLocations.length === 0) return 0;
  
  if (customDivisor && customDivisor > 0) {
    const totalWeekly = activeLocations.reduce((sum, loc) => sum + safeNum(loc.weeklyRent), 0);
    return Number((totalWeekly / customDivisor).toFixed(2));
  }

  // Sum of each booth's allocated daily rent based on its operating days
  const totalDaily = activeLocations.reduce((sum, loc) => {
    return sum + calculateLocationDailyRent(loc);
  }, 0);

  return Number(totalDaily.toFixed(2));
};

export const calculateLocationDailyShare = (
  locationWeeklyRent: number,
  totalLocationsCount: number
): number => {
  const divisor = totalLocationsCount > 0 ? totalLocationsCount : 1;
  return Number((safeNum(locationWeeklyRent) / divisor).toFixed(2));
};

export const calculateTotalWeeklyRent = (locations: BusinessLocation[]): number => {
  if (!locations || locations.length === 0) return 0;
  return locations
    .filter((loc) => loc.isActive)
    .reduce((sum, loc) => sum + safeNum(loc.weeklyRent), 0);
};

// Returns start and end dates of a week containing the given date string (Mon - Sun)
export const getWeekBounds = (dateStr: string): { startDate: string; endDate: string; weekLabel: string } => {
  const d = new Date(dateStr + 'T00:00:00');
  const day = d.getDay(); // 0 is Sunday, 1 is Monday
  const diffToMonday = day === 0 ? -6 : 1 - day;
  
  const monday = new Date(d);
  monday.setDate(d.getDate() + diffToMonday);
  
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const startIso = monday.toISOString().split('T')[0];
  const endIso = sunday.toISOString().split('T')[0];

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const weekLabel = `${monthNames[monday.getMonth()]} ${monday.getDate()} – ${monthNames[sunday.getMonth()]} ${sunday.getDate()}, ${sunday.getFullYear()}`;

  return {
    startDate: startIso,
    endDate: endIso,
    weekLabel,
  };
};

// Generates list of weeks for a given month YYYY-MM
export const getWeeksInMonth = (yearMonth: string): Array<{ startDate: string; endDate: string; label: string; weekNum: number }> => {
  const [yearStr, monthStr] = yearMonth.split('-');
  const year = parseInt(yearStr, 10);
  const month = parseInt(monthStr, 10) - 1;

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);

  const weeks: Array<{ startDate: string; endDate: string; label: string; weekNum: number }> = [];
  let curr = new Date(firstDayOfMonth);
  let weekIndex = 1;

  while (curr <= lastDayOfMonth) {
    const { startDate, endDate, weekLabel } = getWeekBounds(curr.toISOString().split('T')[0]);
    
    if (!weeks.some((w) => w.startDate === startDate)) {
      weeks.push({
        startDate,
        endDate,
        label: `Week ${weekIndex} (${weekLabel})`,
        weekNum: weekIndex,
      });
      weekIndex++;
    }

    curr.setDate(curr.getDate() + 7);
  }

  return weeks;
};

// Aggregates for a week range
export interface WeeklySummaryData {
  startDate: string;
  endDate: string;
  records: DailyRecord[];
  daysLogged: number;
  totalWeeklyRevenue: number;
  totalWeeklyRent: number;
  totalStaffSalary: number;
  ownersDraw: number;
  netProfit: number;
  profitMargin: number;
}

export const calculateWeeklySummary = (
  startDate: string,
  endDate: string,
  records: DailyRecord[],
  locations: BusinessLocation[],
  ownerDraws: WeeklyOwnerDraw[]
): WeeklySummaryData => {
  const filteredRecords = records.filter((r) => r.date >= startDate && r.date <= endDate);
  
  const totalWeeklyRevenue = filteredRecords.reduce((sum, r) => sum + safeNum(r.totalCashIn), 0);
  const totalStaffSalary = filteredRecords.reduce((sum, r) => sum + safeNum(r.totalStaffSalary), 0);
  
  // Total weekly rental is sum of daily rent snapshots from logged days, or weekly total of active booths
  const totalWeeklyRent = filteredRecords.length > 0
    ? filteredRecords.reduce((sum, r) => sum + safeNum(r.dailyRentSnapshot), 0)
    : calculateTotalWeeklyRent(locations);
  
  const drawEntry = ownerDraws.find((d) => d.startDate === startDate);
  const ownersDraw = drawEntry ? safeNum(drawEntry.amount) : 0;
  
  const totalExpenses = totalWeeklyRent + totalStaffSalary + ownersDraw;
  const netProfit = totalWeeklyRevenue - totalExpenses;
  const profitMargin = totalWeeklyRevenue > 0 ? netProfit / totalWeeklyRevenue : 0;

  return {
    startDate,
    endDate,
    records: filteredRecords,
    daysLogged: filteredRecords.length,
    totalWeeklyRevenue,
    totalWeeklyRent,
    totalStaffSalary,
    ownersDraw,
    netProfit,
    profitMargin,
  };
};

// Monthly Summary Calculation
export interface MonthlySummaryData {
  yearMonth: string; // YYYY-MM
  records: DailyRecord[];
  daysLogged: number;
  totalRevenue: number;
  totalBankRevenue: number;
  totalCashRevenue: number;
  totalStaffSalaries: number;
  totalRental: number;
  totalOwnersDraw: number;
  totalInventoryCost: number;
  totalExpenses: number;
  monthlyNetProfit: number;
  profitMargin: number;
}

export const calculateMonthlySummary = (
  yearMonth: string,
  records: DailyRecord[],
  locations: BusinessLocation[],
  ownerDraws: WeeklyOwnerDraw[],
  inventoryItems: InventoryItem[]
): MonthlySummaryData => {
  const monthlyRecords = records.filter((r) => r.date.startsWith(yearMonth));
  
  const totalBankRevenue = monthlyRecords.reduce((sum, r) => sum + safeNum(r.bankRevenue), 0);
  const totalCashRevenue = monthlyRecords.reduce((sum, r) => sum + safeNum(r.cashRevenue), 0);
  const totalRevenue = totalBankRevenue + totalCashRevenue;

  const totalStaffSalaries = monthlyRecords.reduce((sum, r) => sum + safeNum(r.totalStaffSalary), 0);

  // Total Monthly Rental:
  // If records exist, sum the daily rent recorded on each day
  // If no records yet, estimate daily rent * 26 days
  const totalRental = monthlyRecords.length > 0
    ? monthlyRecords.reduce((sum, r) => sum + safeNum(r.dailyRentSnapshot), 0)
    : Number((calculateTotalDailyRent(locations) * 26).toFixed(2));

  const totalOwnersDraw = ownerDraws
    .filter((d) => d.startDate.startsWith(yearMonth) || d.endDate.startsWith(yearMonth))
    .reduce((sum, d) => sum + safeNum(d.amount), 0);

  const totalInventoryCost = inventoryItems
    .filter((item) => !item.purchaseDate || item.purchaseDate.startsWith(yearMonth))
    .reduce((sum, item) => sum + safeNum(item.totalCost), 0);

  const totalExpenses = totalRental + totalStaffSalaries + totalOwnersDraw + totalInventoryCost;
  const monthlyNetProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? monthlyNetProfit / totalRevenue : 0;

  return {
    yearMonth,
    records: monthlyRecords,
    daysLogged: monthlyRecords.length,
    totalRevenue,
    totalBankRevenue,
    totalCashRevenue,
    totalStaffSalaries,
    totalRental,
    totalOwnersDraw,
    totalInventoryCost,
    totalExpenses,
    monthlyNetProfit,
    profitMargin,
  };
};
