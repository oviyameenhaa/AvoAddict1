import { AppState, BusinessLocation, DailyRecord, InventoryItem, WeeklyOwnerDraw } from '../types';
import { calculateTotalDailyRent } from './calculations';
import * as XLSX from 'xlsx';

const STORAGE_KEY = 'avoaddict_app_data_v3';

// Pre-loaded booth locations matching user's exact example:
// Bangsar: 1000, Sunway: 2000, KLCC: 1000
// Per day = (1000 + 2000 + 1000) / 3 = RM 1,333.33 / day
export const getInitialLocations = (): BusinessLocation[] => [
  {
    id: 'loc-1',
    name: 'Bangsar',
    code: 'AA-BSR',
    weeklyRent: 1000,
    operatingDays: 6,
    dailyRent: 1000 / 6,
    managerName: 'Farhan Azman',
    isActive: true,
  },
  {
    id: 'loc-2',
    name: 'Sunway',
    code: 'AA-SWY',
    weeklyRent: 2000,
    operatingDays: 6,
    dailyRent: 2000 / 6,
    managerName: 'Nurul Huda',
    isActive: true,
  },
  {
    id: 'loc-3',
    name: 'KLCC',
    code: 'AA-KLCC',
    weeklyRent: 1000,
    operatingDays: 6,
    dailyRent: 1000 / 6,
    managerName: 'Jason Lee',
    isActive: true,
  },
];

export const getInitialInventory = (currentMonthStr: string): InventoryItem[] => [
  {
    id: 'inv-1',
    name: 'Avocado (Grade A Hass)',
    category: 'Fresh Produce',
    quantity: 80,
    unit: 'kg',
    unitCost: 14.50,
    totalCost: 1160.00,
    purchaseDate: `${currentMonthStr}-01`,
    isDefault: true,
  },
  {
    id: 'inv-2',
    name: 'Wakame (Seasoned Seaweed)',
    category: 'Pantry & Specialty',
    quantity: 25,
    unit: 'packs (1kg)',
    unitCost: 28.00,
    totalCost: 700.00,
    purchaseDate: `${currentMonthStr}-02`,
    isDefault: true,
  },
  {
    id: 'inv-3',
    name: 'Botol (Bottles 500ml PET)',
    category: 'Packaging',
    quantity: 1200,
    unit: 'pcs',
    unitCost: 0.85,
    totalCost: 1020.00,
    purchaseDate: `${currentMonthStr}-01`,
    isDefault: true,
  },
  {
    id: 'inv-4',
    name: 'NSK (Specialty Base Mix)',
    category: 'Core Ingredient',
    quantity: 35,
    unit: 'tins',
    unitCost: 45.00,
    totalCost: 1575.00,
    purchaseDate: `${currentMonthStr}-03`,
    isDefault: true,
  },
  {
    id: 'inv-5',
    name: 'Susu (Fresh Farm Milk)',
    category: 'Dairy',
    quantity: 220,
    unit: 'liters',
    unitCost: 6.80,
    totalCost: 1496.00,
    purchaseDate: `${currentMonthStr}-02`,
    isDefault: true,
  },
];

// Helper to generate seed daily records in RM with exact (1000+2000+1000)/3 = 1333.33 daily rent
export const getInitialDailyRecords = (locations: BusinessLocation[]): DailyRecord[] => {
  const records: DailyRecord[] = [];
  const totalDailyRent = calculateTotalDailyRent(locations); // 1333.33
  
  const today = new Date();
  for (let i = 13; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayOfWeek = d.getDay();

    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const baseBank = isWeekend ? 3400 : 2500;
    const baseCash = isWeekend ? 1600 : 1100;
    
    const seed = (i * 43) % 100;
    const bankRev = Math.round(baseBank + (seed * 11.5));
    const cashRev = Math.round(baseCash + (seed * 5.2));
    const totalIn = bankRev + cashRev;

    const staff = [
      { id: `stf-1-${dateStr}`, name: 'Ahmad Faiz', amount: 140, bottlesSold: Math.round(36 + (seed % 14)) },
      { id: `stf-2-${dateStr}`, name: 'Kelly Tan', amount: 110, bottlesSold: Math.round(48 + (seed % 22)) },
      { id: `stf-3-${dateStr}`, name: 'Danial Haziq', amount: 95, bottlesSold: Math.round(28 + (seed % 12)) },
      ...(isWeekend ? [{ id: `stf-4-${dateStr}`, name: 'Priya Nair', amount: 90, bottlesSold: Math.round(32 + (seed % 10)) }] : []),
    ];

    const totalStaffSalary = staff.reduce((acc, s) => acc + s.amount, 0);
    const totalCashOut = totalDailyRent + totalStaffSalary;
    const netBalance = totalIn - totalCashOut;

    records.push({
      id: `rec-${dateStr}`,
      date: dateStr,
      locationId: 'ALL',
      bankRevenue: bankRev,
      cashRevenue: cashRev,
      totalCashIn: totalIn,
      staffSalaries: staff,
      totalStaffSalary,
      dailyRentSnapshot: totalDailyRent,
      totalCashOut,
      netDailyBalance: netBalance,
      notes: isWeekend ? 'Weekend promotion active across Bangsar, Sunway & KLCC booths.' : 'Regular weekday operations.',
    });
  }

  return records;
};

export const getInitialWeeklyOwnerDraws = (records: DailyRecord[]): WeeklyOwnerDraw[] => {
  if (records.length === 0) return [];
  const today = new Date();
  const d1 = new Date(today);
  d1.setDate(d1.getDate() - 10);
  const d2 = new Date(today);
  d2.setDate(d2.getDate() - 3);

  return [
    {
      weekKey: 'prev-week',
      startDate: d1.toISOString().split('T')[0],
      endDate: new Date(d1.getTime() + 6 * 86400000).toISOString().split('T')[0],
      amount: 1500,
      notes: "Bi-weekly founder draw (Week A)",
    },
    {
      weekKey: 'curr-week',
      startDate: d2.toISOString().split('T')[0],
      endDate: new Date(d2.getTime() + 6 * 86400000).toISOString().split('T')[0],
      amount: 1800,
      notes: "Founder distribution (Week B)",
    },
  ];
};

export const loadAppState = (): AppState => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AppState;
      if (parsed && Array.isArray(parsed.locations) && parsed.locations.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to parse state from localStorage, initializing defaults', err);
  }

  const locations = getInitialLocations();
  const now = new Date();
  const currMonth = now.toISOString().substring(0, 7);
  const inventoryItems = getInitialInventory(currMonth);
  const dailyRecords = getInitialDailyRecords(locations);
  const weeklyOwnerDraws = getInitialWeeklyOwnerDraws(dailyRecords);

  const defaultState: AppState = {
    locations,
    dailyRecords,
    weeklyOwnerDraws,
    inventoryItems,
  };

  saveAppState(defaultState);
  return defaultState;
};

export const saveAppState = (state: AppState): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to write app state to localStorage', err);
  }
};

// ==========================================
// EXCEL (.XLSX) EXPORT IMPLEMENTATIONS (TABLET & ALL DEVICES)
// ==========================================

export const downloadExcelFile = (workbook: XLSX.WorkBook, fileName: string) => {
  try {
    // 1. Generate clean binary array without charset modifiers for universal mobile/tablet OS compatibility
    const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });

    // Check for Internet Explorer / Edge legacy msSaveBlob
    const nav = window.navigator as any;
    if (nav && typeof nav.msSaveOrOpenBlob === 'function') {
      nav.msSaveOrOpenBlob(blob, fileName);
      return;
    }

    // Modern universal cross-device download (iPadOS, iOS Safari, Android tablet/mobile, Chrome, Firefox, Edge, Safari)
    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = fileName;
    link.setAttribute('download', fileName);
    link.target = '_self';
    link.rel = 'noopener noreferrer';

    // CRITICAL for iOS/iPadOS Safari:
    // Never use display:none because WebKit drops programmatic click() events on hidden elements!
    // Using offscreen fixed positioning ensures full visibility in DOM while remaining invisible to user.
    link.style.position = 'fixed';
    link.style.top = '-9999px';
    link.style.left = '-9999px';
    link.style.width = '1px';
    link.style.height = '1px';
    link.style.opacity = '0';
    link.style.pointerEvents = 'none';

    document.body.appendChild(link);

    // Dispatch real MouseEvent for tablets/mobile browsers where link.click() may be restricted
    try {
      const clickEvent = new MouseEvent('click', {
        view: window,
        bubbles: true,
        cancelable: true,
      });
      link.dispatchEvent(clickEvent);
    } catch {
      link.click();
    }

    // Clean up DOM and blob URL safely after delay
    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
      URL.revokeObjectURL(blobUrl);
    }, 2500);
  } catch (err) {
    console.warn('Blob Excel download failed, attempting XLSX.writeFile fallback:', err);
    try {
      XLSX.writeFile(workbook, fileName);
    } catch (fallbackErr) {
      console.error('All Excel download methods failed:', fallbackErr);
    }
  }
};

export const exportMonthlyReportToExcel = (
  month: string,
  summary: {
    totalRevenue: number;
    totalBankRevenue: number;
    totalCashRevenue: number;
    totalRental: number;
    totalStaffSalaries: number;
    totalOwnersDraw: number;
    totalInventoryCost: number;
    monthlyNetProfit: number;
    profitMargin: number;
  },
  records: DailyRecord[],
  locations: BusinessLocation[]
): void => {
  const wb = XLSX.utils.book_new();

  // 1. P&L Summary Sheet
  const summaryData = [
    ['AvoAddict - Monthly Financial & Operations Statement'],
    [`Month: ${month}`],
    [`Generated: ${new Date().toLocaleDateString('en-MY')}`],
    [''],
    ['Executive Metric', 'Amount (RM)'],
    ['Total Gross Sales', summary.totalRevenue],
    ['  - Bank & DuitNow QR', summary.totalBankRevenue],
    ['  - Cash Register Receipts', summary.totalCashRevenue],
    ['Total Operating Expenses', summary.totalRental + summary.totalStaffSalaries + summary.totalOwnersDraw + summary.totalInventoryCost],
    ['  - Booth Locations Rental', summary.totalRental],
    ['  - Crew Staff Payroll', summary.totalStaffSalaries],
    ['  - Inventory Goods Cost', summary.totalInventoryCost],
    ['  - Founder / Owner Draw', summary.totalOwnersDraw],
    ['Net Monthly Profit', summary.monthlyNetProfit],
    ['Net Profit Margin', `${(summary.profitMargin * 100).toFixed(2)}%`],
    [''],
    ['Active Booth Locations in Week', 'Weekly Rent (RM)', 'Daily Share (RM)'],
    ...locations.filter((l) => l.isActive).map((l) => [
      l.name,
      l.weeklyRent,
      Number((l.weeklyRent / locations.filter((x) => x.isActive).length).toFixed(2)),
    ]),
    ['Total Weekly Rent', locations.filter((l) => l.isActive).reduce((acc, l) => acc + l.weeklyRent, 0)],
    ['Total Daily Rent Formula', `(Sum Weekly Rents) / ${locations.filter((l) => l.isActive).length} booths = RM ${calculateTotalDailyRent(locations).toFixed(2)}/day`],
  ];

  const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'P&L Summary');

  // 2. Daily Ledger Sheet
  const ledgerHeader = [
    'Date',
    'Bank (RM)',
    'Cash (RM)',
    'Total In (RM)',
    'Daily Rent (RM)',
    'Staff Payroll (RM)',
    'Total Out (RM)',
    'Net Balance (RM)',
    'Bottles Sold (btls)',
    'Staff On Duty & Bottles Sold',
    'Shift Remarks',
  ];

  const ledgerRows = records.map((r) => {
    const totalBottles = (r.staffSalaries || []).reduce((sum, s) => sum + (s.bottlesSold || 0), 0);
    const staffBreakdown = (r.staffSalaries || [])
      .map((s) => `${s.name || 'Staff'}${s.bottlesSold !== undefined && s.bottlesSold > 0 ? ` (${s.bottlesSold} btls)` : ''}`)
      .join(', ');

    return [
      r.date,
      r.bankRevenue,
      r.cashRevenue,
      r.totalCashIn,
      r.dailyRentSnapshot,
      r.totalStaffSalary,
      r.totalCashOut,
      r.netDailyBalance,
      totalBottles,
      staffBreakdown || 'None',
      r.notes || '',
    ];
  });

  const wsLedger = XLSX.utils.aoa_to_sheet([ledgerHeader, ...ledgerRows]);
  XLSX.utils.book_append_sheet(wb, wsLedger, 'Daily Ledger');

  downloadExcelFile(wb, `AvoAddict_Financial_Report_${month}.xlsx`);
};

export const exportWeeklyReportToExcel = (
  startDate: string,
  endDate: string,
  summary: any,
  records: DailyRecord[]
): void => {
  const wb = XLSX.utils.book_new();

  // 1. Weekly Overview Sheet
  const overviewData = [
    ['AvoAddict Weekly Financial & Operations Report'],
    ['Accounting Period', `${startDate} to ${endDate}`],
    ['Generated On', new Date().toLocaleString()],
    [],
    ['FINANCIAL METRIC', 'AMOUNT (RM)'],
    ['Total Weekly Revenue', summary.totalWeeklyRevenue],
    ['Total Weekly Rental (Active Booths)', summary.totalWeeklyRent],
    ['Total Staff Payroll', summary.totalStaffSalary],
    ['Owner Salary / Draw', summary.ownersDraw],
    ['Total Weekly Overhead', summary.totalWeeklyRent + summary.totalStaffSalary + summary.ownersDraw],
    ['Weekly Net Profit', summary.netProfit],
    ['Net Profit Margin', `${(summary.profitMargin * 100).toFixed(1)}%`],
    ['Active Working Days Logged', summary.daysLogged],
  ];

  const wsOverview = XLSX.utils.aoa_to_sheet(overviewData);
  XLSX.utils.book_append_sheet(wb, wsOverview, 'Weekly Summary');

  // 2. Daily Shifts in Week
  const ledgerHeader = [
    'Date',
    'Bank (RM)',
    'Cash (RM)',
    'Total In (RM)',
    'Daily Rent (RM)',
    'Staff Payroll (RM)',
    'Total Out (RM)',
    'Net Balance (RM)',
    'Bottles Sold (btls)',
    'Crew On Duty & Bottles Sold',
    'Shift Remarks',
  ];

  const ledgerRows = records.map((r) => {
    const totalBottles = (r.staffSalaries || []).reduce((sum, s) => sum + (s.bottlesSold || 0), 0);
    const staffBreakdown = (r.staffSalaries || [])
      .map((s) => `${s.name || 'Staff'}${s.bottlesSold !== undefined && s.bottlesSold > 0 ? ` (${s.bottlesSold} btls)` : ''}`)
      .join(', ');

    return [
      r.date,
      r.bankRevenue,
      r.cashRevenue,
      r.totalCashIn,
      r.dailyRentSnapshot,
      r.totalStaffSalary,
      r.totalCashOut,
      r.netDailyBalance,
      totalBottles,
      staffBreakdown || 'None',
      r.notes || '',
    ];
  });

  const wsLedger = XLSX.utils.aoa_to_sheet([ledgerHeader, ...ledgerRows]);
  XLSX.utils.book_append_sheet(wb, wsLedger, 'Week Daily Shifts');

  downloadExcelFile(wb, `AvoAddict_Weekly_Report_${startDate}.xlsx`);
};

export const exportDailyLedgerToExcel = (records: DailyRecord[]): void => {
  const wb = XLSX.utils.book_new();

  const ledgerHeader = [
    'Date',
    'Bank Sales (RM)',
    'Cash Sales (RM)',
    'Total Sales In (RM)',
    'Daily Rent (RM)',
    'Staff Salaries (RM)',
    'Total Cash Out (RM)',
    'Net Daily Balance (RM)',
    'Total Bottles Sold (btls)',
    'Staff Shifts Count',
    'Staff Names & Bottles Sold',
    'Shift Remarks',
  ];

  const rows = records.map((r) => {
    const totalBottles = (r.staffSalaries || []).reduce((sum, s) => sum + (s.bottlesSold || 0), 0);
    const staffBreakdown = (r.staffSalaries || [])
      .map((s) => `${s.name || 'Staff'}${s.bottlesSold !== undefined ? ` (${s.bottlesSold} btls)` : ''}`)
      .filter(Boolean)
      .join(', ');

    return [
      r.date,
      r.bankRevenue,
      r.cashRevenue,
      r.totalCashIn,
      r.dailyRentSnapshot,
      r.totalStaffSalary,
      r.totalCashOut,
      r.netDailyBalance,
      totalBottles,
      r.staffSalaries.length,
      staffBreakdown,
      r.notes || '',
    ];
  });

  const ws = XLSX.utils.aoa_to_sheet([ledgerHeader, ...rows]);
  XLSX.utils.book_append_sheet(wb, ws, 'AvoAddict Daily Ledger');

  const todayStr = new Date().toISOString().split('T')[0];
  downloadExcelFile(wb, `AvoAddict_Daily_Ledger_${todayStr}.xlsx`);
};

export const exportInventoryToExcel = (items: InventoryItem[], month: string): void => {
  const wb = XLSX.utils.book_new();

  const headers = ['Item Name', 'Category', 'Quantity', 'Unit', 'Unit Cost (RM)', 'Total Cost (RM)', 'Purchase Date'];
  const rows = items.map((i) => [
    i.name,
    i.category,
    i.quantity,
    i.unit,
    i.unitCost,
    i.totalCost,
    i.purchaseDate,
  ]);

  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  XLSX.utils.book_append_sheet(wb, ws, 'Inventory & Supplies');

  downloadExcelFile(wb, `AvoAddict_Inventory_${month}.xlsx`);
};

export const exportAppStateAsJSON = (state: AppState): void => {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  const dateStr = new Date().toISOString().split('T')[0];
  downloadAnchor.setAttribute('download', `AvoAddict_Backup_${dateStr}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
};

export const exportDailyRecordsToCSV = (records: DailyRecord[]): void => {
  const headers = [
    'Date',
    'Bank Revenue (RM)',
    'Cash Revenue (RM)',
    'Total Cash In (RM)',
    'Daily Rent (RM)',
    'Staff Salaries (RM)',
    'Total Cash Out (RM)',
    'Net Daily Balance (RM)',
    'Staff Count',
    'Notes',
  ];

  const rows = records.map((r) => [
    r.date,
    r.bankRevenue.toFixed(2),
    r.cashRevenue.toFixed(2),
    r.totalCashIn.toFixed(2),
    r.dailyRentSnapshot.toFixed(2),
    r.totalStaffSalary.toFixed(2),
    r.totalCashOut.toFixed(2),
    r.netDailyBalance.toFixed(2),
    r.staffSalaries.length,
    `"${(r.notes || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `AvoAddict_Daily_Ledger_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  link.remove();
};

